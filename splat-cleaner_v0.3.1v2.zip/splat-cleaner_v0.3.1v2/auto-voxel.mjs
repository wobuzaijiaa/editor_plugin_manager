/** Zero-UI-parameter voxel resolution policy for SplatTransform filterFloaters.
 * This is a conservative experimental heuristic, NOT a SplatTransform default.
 * Inputs are world-space Gaussian centers and log-standard-deviation scales.
 */
export function autoVoxelResolution(columns, {maxCells=2_000_000,maxAxisCells=256,sampleSize=8192}={}) {
    const n=columns?.x?.length;
    if (!Number.isInteger(n) || n<1 || !['y','z','scale_0','scale_1','scale_2'].every(k=>columns[k]?.length===n))
        throw new Error('Incomplete instance-aligned Gaussian columns for automatic voxel sizing.');
    const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
    for(let i=0;i<n;i++) {
        const logs=[columns.scale_0[i],columns.scale_1[i],columns.scale_2[i]];
        if(logs.some(v=>!Number.isFinite(v))) throw new Error('Invalid Gaussian log-scale for automatic voxel sizing.');
        // Conservative rotation-independent 3-sigma AABB, to approximate the
        // bounds of the actual GPU voxelization (which uses Gaussian extents).
        const radius=3*Math.exp(Math.max(...logs));
        if(!Number.isFinite(radius)||radius<=0) throw new Error('Invalid Gaussian radius for automatic voxel sizing.');
        for(let a=0;a<3;a++) {
            const v=columns[['x','y','z'][a]][i];
            if(!Number.isFinite(v))throw new Error('Invalid Gaussian center for automatic voxel sizing.');
            if(v-radius<min[a])min[a]=v-radius;
            if(v+radius>max[a])max[a]=v+radius;
        }
    }
    const scales=[];
    const stride=Math.max(1,Math.floor(n/sampleSize));
    for(let i=0;i<n && scales.length<sampleSize;i+=stride) {
        const ls=[columns.scale_0[i],columns.scale_1[i],columns.scale_2[i]];
        if(ls.some(v=>!Number.isFinite(v)))throw new Error('Invalid Gaussian log-scale for automatic voxel sizing.');
        ls.sort((a,b)=>a-b);
        const middle=Math.exp(ls[1]);
        if(!Number.isFinite(middle)||middle<=0) throw new Error('Invalid Gaussian scale for automatic voxel sizing.');
        scales.push(middle);
    }
    scales.sort((a,b)=>a-b);
    const medianScale=scales[Math.floor(scales.length/2)];
    const extent=max.map((v,a)=>v-min[a]);
    const longest=Math.max(...extent);
    if(!(longest>0) || !Number.isFinite(longest))throw new Error('Degenerate or invalid model extent for automatic voxel sizing.');
    // Median middle principal scale reduces sensitivity to thin sheets and a few elongated splats.
    // Budgeted grid controls worst-case voxel counts, not the GPU BVH or all downstream allocations.
    let width=Math.max(2*medianScale,longest/maxAxisCells);
    const estimate=h=>extent.reduce((product,d)=>product*(Math.ceil(d/h)+8),1);
    for(let step=0;step<100 && estimate(width)>maxCells;step++)width*=1.25;
    if(!Number.isFinite(width) || width<=0 || estimate(width)>maxCells)
        throw new Error('Automatic voxel sizing cannot satisfy its grid budget.');
    return {
        voxelResolution:width,
        opacityCutoff:0.1,
        minContribution:1/255,
        policy:'median_middle_scale_x2_with_grid_budget_v1',
        medianMiddleScale:medianScale,
        estimatedGaussianExtent:extent,
        estimatedGridCells:estimate(width),
        maxEstimatedGridCells:maxCells
    };
}
