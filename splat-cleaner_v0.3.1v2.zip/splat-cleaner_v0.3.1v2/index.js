/** Region-Aware Splat Cleaner v0.3.1; managed external plugin; import has no side effects.
 * Audited integration pattern: XYZ v1.0.4 / SuperSplat 3.7.0/v3.8.0; pinned internal API contracts.
 * Internal SuperSplat scene APIs are version-sensitive; not a general plugin SDK.
 */
import { assert, tick, analyzeDensity, computeSelection, previewHidden, subsetRuns, buildReport, analyzeComponents, AXES } from './core.mjs';
import { readFloaterColumns, runSplatTransformFloaters, loadSplatTransformBridge } from './floater-adapter.mjs';
import { autoVoxelResolution } from './auto-voxel.mjs';
import { readSnsGeometry, analyzeSnsSupport } from './sns-support.mjs';
const showError = error => error instanceof Error ? error.message : String(error);
function validatedSnsParameters(kValue,mValue) {
    const k=Number(kValue),m=Number(mValue);
    assert(Number.isFinite(k) && k>=1 && k<=5 && Number.isInteger(k*2),
        'SNS k must be 1–5 in steps of 0.5.');
    assert(Number.isInteger(m) && m>=1 && m<=10, 'SNS m must be an integer 1–10.');
    return {k,m};
}
// Temporary preflight based on the ~0.92M working model and ~8.90M failed model.
// This is a conservative policy, NOT a validated universal GPU limit.
const MAX_UNVALIDATED_GPU_FLOATERS = 2_000_000;

// Only the UI is rounded. Internal model bounds, masks and export use full precision.
const display3 = value => Number.isFinite(value) ? Number(value.toFixed(3)).toFixed(3) : '';
const round3 = value => Number(value.toFixed(3));
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
function reviseRoiInterval(interval, domain, side, value) {
    assert(side === 'min' || side === 'max', 'Invalid ROI endpoint.');
    assert(Number.isFinite(value), 'ROI coordinate must be finite.');
    const next = { ...interval, [side]: clamp(value, domain.min, domain.max) };
    if (next.min > next.max) next[side] = next[side === 'min' ? 'max' : 'min'];
    return next;
}
const dl = (bytes, filename) => {
    const url = URL.createObjectURL(new Blob([bytes], {type:'application/json'}));
    const link = document.createElement('a'); link.href = url; link.download = filename;
    document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
};
function modelAttached(scene, splat) {
    return !!splat && scene.elements?.includes(splat) && splat.scene === scene && !!splat.instances && !!splat.resource?.source;
}
function loadedSplats(scene) { return scene.elements.filter(e => modelAttached(scene, e)); }
function selectedModel(scene, splat) {
    assert(modelAttached(scene, splat), 'Selected 3DGS model was removed. Refresh models.');
    assert(splat.visible, 'Selected model is hidden in the Editor. Make it visible first.');
    return splat;
}
function transformOf(splat, id) {
    const palette = splat.worldTransform.clone();
    splat.transformPalette.getTransform(id, palette);
    return splat.worldTransform.clone().mul2(splat.worldTransform, palette);
}
function similarTransformScale(matrix) {
    // Effective principal scale is max(source std-dev) * uniform world-scale.
    // Reject shears and nonuniform or singular transforms instead of mislabeling sizes.
    const m = matrix.data || matrix;
    if (!m || m.length !== 16) return null;
    const c = [[m[0],m[1],m[2]], [m[4],m[5],m[6]], [m[8],m[9],m[10]]];
    const lens = c.map(v => Math.hypot(...v));
    const factor = (lens[0] + lens[1] + lens[2]) / 3;
    if (!Array.from(m).every(Number.isFinite) || Math.abs(m[3])>1e-6 || Math.abs(m[7])>1e-6 ||
        Math.abs(m[11])>1e-6 || Math.abs(m[15]-1)>1e-6 ||
        !Number.isFinite(factor) || factor <= 1e-12 || lens.some(l => Math.abs(l-factor) > 1e-4 * factor)) return null;
    for (let i=0;i<3;i++) for (let j=i+1;j<3;j++) {
        const dot = c[i].reduce((sum,v,k) => sum+v*c[j][k],0);
        if (Math.abs(dot) > 1e-4*factor*factor) return null;
    }
    return factor;
}
function indicesFromPredicate(total, predicate) {
    // Native GaussianInstances setBits()/clearBits() reads .forEach(), not array type.
    return { forEach(fn) { for (let i=0;i<total;i++) if (predicate(i)) fn(i); } };
}
function isolationFor(scene, target) {
    const hidden = new Map();
    let revision = 0;
    const conceal = element => {
        if (element === target || !modelAttached(scene, element) || !element.visible) return;
        hidden.set(element, true); element.visible = false; scene.forceRender = true;
    };
    for (const element of loadedSplats(scene)) conceal(element);
    const added = scene.events.on('scene.elementAdded', e => { revision++; conceal(e); });
    const removed = scene.events.on('scene.elementRemoved', () => { revision++; });
    return {
        ensure() { for (const element of loadedSplats(scene)) conceal(element); },
        revision() { return revision; },
        restore() {
            added.off(); removed.off();
            for (const [element, visible] of hidden)
                if (modelAttached(scene, element) && !element.visible) element.visible = visible;
            scene.forceRender = true;
        }
    };
}

/** Read instance-aligned world-space centers and geometric attributes in chunks.
 * SuperSplat 3.8.0 / SplatTransform 3.11.1 ChunkSource geometric.opacity
 * is TRUE LINEAR opacity (canonical chunk/layout.ts contract), unlike the
 * v3.10.2 compatibility source which can pass through raw logits. Users of
 * SuperSplat 3.7.0 select explicit logit interpretation instead of guessing.
 * SplatTransform DataTable.opacity remains logit; the GPU bridge converts.
 */
async function readModel(splat, cancelled, progress, {opacityEncoding='linear'} = {}) {
    assert(['linear','logit'].includes(opacityEncoding), 'Unsupported opacity interpretation.');
    const { source, sourcePool } = splat.resource;
    assert(sourcePool?.acquire && source?.read, 'Gaussian chunk source/pool API unavailable.');
    const n = splat.instances.count;
    assert(n > 0 && Number.isInteger(source.meta.chunkSize) && source.meta.chunkSize > 0,
        'Selected model has no readable Gaussian source.');
    assert(source.meta.layouts.position, 'Missing Gaussian position layer.');
    const centers = { x:new Float64Array(n), y:new Float64Array(n), z:new Float64Array(n) };
    // These are optional. If the installed source does not match the expected
    // field/encoding contract, no attribute filter is offered.
    const layout = source.meta.layouts.geometric;
    const fields = layout?.fields || {};
    const scaleLayout = fields.scale?.components === 3 && fields.scale?.type === 'float32';
    const opacityLayout = fields.opacity?.components === 1 && fields.opacity?.type === 'float32';
    let scaleEnabled = scaleLayout, opacityEnabled = opacityLayout;
    let sizes = scaleEnabled ? new Float32Array(n) : null;
    let opacities = opacityEnabled ? new Float32Array(n) : null;
    let aboveOneCount = 0;
    let opacityFailure = null, scaleFailure = null;
    const transformMap = new Map(), uniformScales = new Map();
    for (let offset=0; offset<n; offset+=source.meta.chunkSize) {
        assert(!cancelled(), 'Analysis cancelled.');
        const count = Math.min(source.meta.chunkSize,n-offset);
        const position = sourcePool.acquire('position', source.meta.layouts.position, count);
        const geometric = layout && (scaleEnabled || opacityEnabled) ? sourcePool.acquire('geometric', layout, count) : null;
        try {
            if (geometric) {
                try { await source.read({indices:splat.instances.sourceRow,indexOffset:offset,count,position,geometric}); }
                catch (_decodeError) {
                    const reason = showError(_decodeError);
                    opacityFailure ||= `geometric layer read failed at source-row offset ${offset}: ${reason}`;
                    scaleFailure ||= `geometric layer read failed at source-row offset ${offset}: ${reason}`;
                    // Density must still be available if optional geometric decoding fails.
                    scaleEnabled=false; opacityEnabled=false;
                    await source.read({indices:splat.instances.sourceRow,indexOffset:offset,count,position});
                }
            } else await source.read({indices:splat.instances.sourceRow,indexOffset:offset,count,position});
            const xyz = new Float32Array(position.data, 0, count*3);
            // Determine field names from runtime metadata instead of guessing a byte offset.
            let s=null, a=null;
            try { s = scaleEnabled ? geometric.field('scale') : null; } catch(e) { scaleFailure ||= `scale field read failed at offset ${offset}: ${showError(e)}`; scaleEnabled=false; }
            try { a = opacityEnabled ? geometric.field('opacity') : null; } catch(e) { opacityFailure ||= `opacity field read failed at offset ${offset}: ${showError(e)}`; opacityEnabled=false; }
            if (scaleEnabled && s?.length !== count*3) { scaleFailure ||= `scale field length at offset ${offset} was ${s?.length ?? 'missing'}, expected ${count*3}`; scaleEnabled = false; }
            if (opacityEnabled && a?.length !== count) { opacityFailure ||= `opacity field length at offset ${offset} was ${a?.length ?? 'missing'}, expected ${count}`; opacityEnabled = false; }
            for (let j=0;j<count;j++) {
                const i=offset+j, palette=splat.instances.transformIndex(i);
                if (!transformMap.has(palette)) {
                    const matrix=transformOf(splat,palette);
                    transformMap.set(palette,matrix);
                    uniformScales.set(palette,similarTransformScale(matrix));
                }
                const m=transformMap.get(palette).data;
                const x=xyz[j*3],y=xyz[j*3+1],z=xyz[j*3+2];
                centers.x[i]=m[0]*x+m[4]*y+m[8]*z+m[12];
                centers.y[i]=m[1]*x+m[5]*y+m[9]*z+m[13];
                centers.z[i]=m[2]*x+m[6]*y+m[10]*z+m[14];
                if (scaleEnabled) {
                    const scale=uniformScales.get(palette);
                    const size=Math.exp(Math.max(s[j*3],s[j*3+1],s[j*3+2])) * scale;
                    if (scale === null || !Number.isFinite(size) || size <= 0) {
                        scaleFailure ||= `invalid effective scale at instance ${i} (source row ${splat.instances.sourceRow[i]})`;
                        scaleEnabled=false;
                    }
                    else sizes[i]=size;
                }
                if (opacityEnabled) {
                    const value=a[j];
                    // Raw logit in legacy v3.10.2 sources; linear in v3.11.1 chunk sources.
                    // +/-Infinity are valid logits representing fully opaque/
                    // transparent alpha; NaN is not. Linear override permits >1.
                    if (Number.isNaN(value) || (opacityEncoding==='linear' && (!Number.isFinite(value) || value<0))) {
                        opacityFailure ||= `invalid ${opacityEncoding} opacity at instance ${i} (source row ${splat.instances.sourceRow[i]}): ${String(value)}`;
                        opacityEnabled=false;
                    } else {
                        const decoded=opacityEncoding==='logit'
                            ? (value>=0 ? 1/(1+Math.exp(-value)) : Math.exp(value)/(1+Math.exp(value)))
                            : value;
                        if (!Number.isFinite(decoded)) {opacityEnabled=false; opacityFailure ||= `decoded opacity is nonfinite at instance ${i}`;}
                        else {opacities[i]=decoded; if(decoded>1) aboveOneCount++;}
                    }
                }
            }
        } finally { position.release(); geometric?.release(); }
        progress(offset+count,n);
        await tick();
    }
    if (!scaleEnabled) sizes=null;
    if (!opacityEnabled) opacities=null;
    return { centers, sizes, opacities, transformMap,
        attributeStatus: {
            size: scaleEnabled ? 'available' : (scaleLayout ? `disabled: ${scaleFailure || 'unsupported effective transform or invalid scale values'}` : 'disabled: source geometric.scale (log std-dev ×3) unavailable'),
            opacity: opacityEnabled ? (opacityEncoding==='logit' ? 'available (raw logit → sigmoid; legacy v3.10.2 source contract)' : (aboveOneCount
                ? `available (linear; ${aboveOneCount.toLocaleString()} values > 1 are permitted)`
                : 'available (linear)'))
                : (opacityLayout ? `disabled: ${opacityFailure || 'non-finite/negative opacity or unreadable source'}`
                    : 'disabled: float32 geometric.opacity unavailable')
        }};
}

/** Reversible preview. Mutates only native locked bit (2), and keeps the
 * original flags, source-row and palette arrays to fail closed on external edits.
 */
class Preview {
    constructor(splat, data) {
        this.splat=splat; this.instances=splat.instances; this.data=data;
        this.original=this.instances.flags.slice(0,this.instances.count);
        this.sourceRows=this.instances.sourceRow.slice(0,this.instances.count);
        this.palette=this.instances.palette.slice(0,this.instances.count);
        this.world=splat.worldTransform.clone();
        this.transforms=new Map([...data.transformMap].map(([id,m])=>[id,m.clone()]));
        this.hidden=null;
    }
    verify(scene) {
        assert(modelAttached(scene,this.splat) && this.splat.visible && this.instances===this.splat.instances &&
            this.instances.count===this.original.length && this.splat.worldTransform.equals(this.world),
            'Selected model changed; preview must be closed and reanalyzed.');
        const n=this.original.length;
        for(let i=0;i<n;i++) {
            assert(this.instances.sourceRow[i]===this.sourceRows[i] && this.instances.palette[i]===this.palette[i],
                'Instance/source mappings changed; preview invalid.');
            assert(this.instances.flags[i] === (this.original[i] | (this.hidden?.[i] ? 2 : 0)),
                'Native Gaussian flags were modified outside Splat Cleaner; unsafe to overwrite.');
        }
        for(const [id,saved] of this.transforms)
            assert(transformOf(this.splat,id).equals(saved), 'Model palette transform changed; reanalyze.');
    }
    setHidden(scene, hidden) {
        this.verify(scene);
        const n=this.original.length;
        assert(hidden.length===n, 'Preview mask length mismatch.');
        this.instances.clearBits(indicesFromPredicate(n,i=>!(this.original[i]&2)),2);
        this.instances.setBits(indicesFromPredicate(n,i=>!!hidden[i]),2);
        // Record CPU state before native GPU upload, so a failed flush cannot
        // make later verification assume the previous mask is still installed.
        this.hidden=hidden;
        try { this.instances.flush(); }
        catch(e) {
            // Restore native CPU-side flags using native mutators, but DO NOT
            // retry writing to a potentially lost GPU device.
            this.instances.clearBits(indicesFromPredicate(n,i=>!(this.original[i]&2)),2);
            this.instances.setBits(indicesFromPredicate(n,i=>!!(this.original[i]&2)),2);
            this.hidden=null;
            this.uploadFailed=true;
            throw e;
        }
        scene.forceRender=true;
    }
    restore(scene) {
        assert(!this.uploadFailed, 'Native GPU preview upload previously failed; reload the Editor. CPU flags have been reverted.');
        this.verify(scene);
        const n=this.original.length;
        this.instances.clearBits(indicesFromPredicate(n,i=>!(this.original[i]&2)),2);
        this.instances.setBits(indicesFromPredicate(n,i=>!!(this.original[i]&2)),2);
        this.hidden=null;  // CPU-side flags have been restored even if GPU upload fails.
        try { this.instances.flush(); } catch(e) { this.uploadFailed=true; throw e; }
        scene.forceRender=true;
        for(let i=0;i<n;i++) assert(this.instances.flags[i]===this.original[i], 'Preview restoration did not preserve original flags.');
    }
}

function makeExportLayers(splat, selection) {
    const ranges=subsetRuns(selection.candidates);
    assert(ranges.count>0, 'No Gaussians remain after candidate removal.');
    assert(typeof splat.createLayer==='function', 'Native subset layer API unavailable.');
    const layer=splat.createLayer(ranges, `${splat.name} (cleaned)`);
    try {
        assert(layer.worldTransform.equals(splat.worldTransform), 'Native export layer transform differs from source.');
        return { layers:[layer], count:ranges.count };
    } catch(e) { layer.destroy(); throw e; }
}

const FORMATS=new Set(['ply','splat','sog','spz']);
function exportChoices(format, choice) {
    assert(FORMATS.has(format) && choice?.filename, 'Invalid export choice.');
    const fileType=format==='ply' && choice.compressedPly ? 'compressedPly' : format;
    return { fileType, options: {
        filename:choice.filename,splatIdx:'all',serializeSettings:{shBands:choice.shBands},
        ...(format==='sog' ? {sogIterations:choice.sogIterations}:{}),
        ...(format==='spz' ? {spzVersion:choice.spzVersion}:{})
    }};
}
function reportName(filename, suffix='') {
    const stem=filename.replace(/\.(?:compressed\.ply|ply|splat|sog|spz)$/i,'');
    return `${stem}.export${suffix}.json`;
}
async function saveReport(report, directory) {
    const bytes=new TextEncoder().encode(JSON.stringify(report,null,2));
    if (directory) {
        let name;
        for (let i=0; i<1000; i++) {
            name=reportName(report.model_file,i?`-${i+1}`:'');
            try { await directory.getFileHandle(name); }
            catch(e) { if(e.name==='NotFoundError') break; throw e; }
            if(i===999) throw new Error('No unused export report filename available.');
        }
        const file=await directory.getFileHandle(name,{create:true});
        const writable=await file.createWritable();
        try { await writable.write(bytes); await writable.close(); }
        catch(e) { try { await writable.abort(); } catch(_) {} throw e; }
        return {delivery:'saved',filename:name};
    }
    const name=reportName(report.model_file);
    dl(bytes,name);
    return {delivery:'download_requested',filename:name};
}

// Shared (same-origin) floating-window stacking across independently loaded plugins.
// Each plugin retains ownership of its own controls, minimize state and cleanup.
function attachPluginWindow(panel, content, minimizeButton) {
    const key = '__supersplatPluginFloatingStackV1';
    const stack = window[key] || (window[key] = { panels: [] });
    const bringToFront = () => {
        stack.panels = stack.panels.filter(item => item !== panel);
        stack.panels.push(panel);
        // Reassign bounded z-indices to avoid unbounded growth after repeated clicks.
        stack.panels.forEach((item, index) => { item.style.zIndex = String(1150 + index); });
    };
    let minimized = false;
    let prior = null;
    const setMinimized = value => {
        if (value === minimized) return;
        if (value) {
            const rect = panel.getBoundingClientRect?.();
            prior = {
                width: Number.isFinite(rect?.width) && rect.width > 0 ? `${rect.width}px` : panel.style.width,
                height: Number.isFinite(rect?.height) && rect.height > 0 ? `${rect.height}px` : panel.style.height,
                minHeight: panel.style.minHeight,
                maxHeight: panel.style.maxHeight,
                resize: panel.style.resize,
                overflow: panel.style.overflow,
                overflowY: panel.style.overflowY,
                contentDisplay: content.style.display
            };
            if (prior.width) panel.style.width = prior.width;
            panel.style.height = 'auto';
            panel.style.minHeight = '0px';
            panel.style.maxHeight = 'calc(100vh - 32px)';
            panel.style.resize = 'none';
            panel.style.overflow = 'hidden';
            panel.style.overflowY = 'hidden';
            content.style.display = 'none';
        } else {
            panel.style.width = prior.width || '';
            panel.style.height = prior.height || '';
            panel.style.minHeight = prior.minHeight || '';
            panel.style.maxHeight = prior.maxHeight || '';
            panel.style.resize = prior.resize || '';
            panel.style.overflow = prior.overflow || '';
            panel.style.overflowY = prior.overflowY || '';
            content.style.display = prior.contentDisplay || '';
        }
        minimized = value;
        minimizeButton.textContent = minimized ? 'Restore' : 'Minimize';
        minimizeButton.setAttribute('aria-expanded', String(!minimized));
        minimizeButton.title = minimized ? 'Restore plugin window' : 'Minimize plugin window';
        minimizeButton.setAttribute('aria-label', minimizeButton.title);
    };
    const onMinimize = () => { setMinimized(!minimized); bringToFront(); };
    minimizeButton.type = 'button';
    minimizeButton.textContent = 'Minimize';
    minimizeButton.setAttribute('aria-expanded', 'true');
    minimizeButton.addEventListener('click', onMinimize);
    panel.addEventListener('pointerdown', bringToFront);
    panel.addEventListener('focusin', bringToFront);
    bringToFront();
    return {
        bringToFront,
        restoreWindow() { setMinimized(false); bringToFront(); },
        isMinimized() { return minimized; },
        dispose() {
            panel.removeEventListener?.('pointerdown', bringToFront);
            panel.removeEventListener?.('focusin', bringToFront);
            minimizeButton.removeEventListener?.('click', onMinimize);
            stack.panels = stack.panels.filter(item => item !== panel);
            stack.panels.forEach((item, index) => { item.style.zIndex = String(1150 + index); });
        }
    };
}

function panelHTML() {
    return `<div id="sc-header" style="display:flex;justify-content:space-between;gap:8px;align-items:center;flex:none">
          <strong style="flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">Region-Aware Splat Cleaner</strong>
          <span style="display:flex;gap:6px;align-items:center"><button id="sc-minimize" type="button" aria-label="Minimize Splat Cleaner">Minimize</button><button id="sc-hide" type="button">Close</button></span></div>
        <div id="sc-window-body" style="display:flex;flex:1 1 auto;min-height:0;flex-direction:column">
        <p id="sc-progress" role="status" style="font-size:11px;color:#bddcff;flex:none;margin:7px 0;max-height:3.4em;overflow-y:auto">Choose a loaded model and Analyze. Preview never deletes splats in place.</p>
        <div id="sc-scroll" tabindex="0" aria-label="Splat Cleaner settings (scrollable)"
          style="flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;scrollbar-gutter:stable;padding-right:4px">
          <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:5px 0">
            <label>Loaded Model <select id="sc-model"></select></label>
            <button id="sc-models" type="button">Refresh</button><button id="sc-analyze" type="button">Analyze</button>
            <button id="sc-sns-find" type="button">Analyze SNS</button>
            <button id="sc-st-find" type="button">Analyze GPU Floaters</button>
          </div>
          <div id="sc-controls" hidden>
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
              <label>Density <select id="sc-density"><option value="all">All</option><option value="sparse">Sparse</option><option value="medium">Medium</option><option value="dense">Dense</option></select></label>
              <button id="sc-roi-reset" type="button">Reset XYZ ROI</button>
            </div>
            <details id="sc-roi-details" style="margin-top:8px"><summary style="cursor:pointer">XYZ region (world coordinates; 3 d.p.)</summary>
              <div id="sc-roi" style="margin:7px 0"></div>
            </details>
            <details id="sc-rules-details" style="margin-top:8px"><summary style="cursor:pointer">Candidate rules (off by default)</summary>
              <fieldset style="border:1px solid #555;margin:7px 0;padding:8px">
                <label><input type="checkbox" id="sc-size-enabled"> Large Gaussian size (scope percentile)</label>
                <label style="display:block;margin:5px 0 9px">Percentile <input id="sc-size-p" type="number" min="1" max="100" value="99" step="0.5" style="width:65px"></label>
                <label><input type="checkbox" id="sc-sns-enabled" disabled> Include SNS isolated candidates (experimental)</label>
                <div style="display:flex;gap:10px;flex-wrap:wrap;margin:5px 0">
                  <label>Extent k <input id="sc-sns-k" type="number" min="1" max="5" step="0.5" value="3" style="width:56px"></label>
                  <label>Min. neighbors m <input id="sc-sns-m" type="number" min="1" max="10" step="1" value="1" style="width:56px"></label>
                </div>
                <p id="sc-sns-status" style="font-size:11px;color:#b9c2cf;margin:5px 0 9px;white-space:pre-wrap">Not analyzed. Default k=3, m=1. Click Analyze SNS.</p>
                <label><input type="checkbox" id="sc-opacity-enabled"> Low opacity</label>
                <label style="display:block;margin:5px 0">Below <input id="sc-opacity" type="number" min="0" max="1" value="0.01" step="0.005" style="width:80px"></label>
                <label style="display:block;margin:5px 0 9px;font-size:11px">Source opacity interpretation <select id="sc-opacity-encoding" style="max-width:100%"><option value="linear">Linear (default for v3.11.1 / Editor v3.8)</option><option value="logit">Raw logit → sigmoid (legacy v3.10.2 / Editor v3.7)</option></select></label>
                <p id="sc-attributes" style="font-size:11px;color:#b9c2cf;overflow-wrap:anywhere"></p>
              </fieldset>
            </details>
            <details id="sc-floater-details" style="margin-top:8px"><summary style="cursor:pointer">Detached components / floater candidates (experimental)</summary>
              <fieldset style="border:1px solid #555;margin:7px 0;padding:8px">
                <div style="display:flex;flex-wrap:wrap;align-items:center;gap:7px">
                  <button id="sc-find-components" type="button">Find components</button>
                  <label><input type="checkbox" id="sc-floater-enabled" disabled> Select small components</label>
                </div>
                <label style="display:block;margin:9px 0">Maximum Gaussian instances per candidate component
                  <input id="sc-component-max" type="number" min="1" max="100000" step="10" value="500" style="width:85px"></label>
                <label style="display:block;margin:6px 0">Or select one detached component for inspection
                  <select id="sc-component-select" disabled style="width:100%;max-width:100%;box-sizing:border-box"><option value="">None — analyze first</option></select>
                </label>
                <p id="sc-component-status" style="font-size:11px;color:#b9c2cf;white-space:pre-wrap">Not calculated. Optional; runs only when requested.</p>
                <p style="font-size:11px;color:#f1d79a">Find identifies groups only. Tick Select small components or choose a group, then Apply / Preview. Export requires at least one candidate.</p>
                <p style="font-size:11px;color:#b9c2cf">26-connected occupied voxels; the largest component is protected. This is a geometric suggestion, not proof of a floater. Sparse legitimate geometry may also be selected.</p>
              </fieldset>
            </details>
            <details id="sc-st-details" style="margin-top:8px"><summary style="cursor:pointer">SplatTransform GPU floater filter (optional)</summary>
              <fieldset style="border:1px solid #555;margin:7px 0;padding:8px">
                <label style="display:block;margin:8px 0"><input type="checkbox" id="sc-st-enabled" disabled> Include GPU floater candidates</label>
                <p id="sc-st-status" style="font-size:11px;color:#b9c2cf;white-space:pre-wrap">Not analyzed. Uses automatically derived voxel resolution and SplatTransform defaults. Requires bundled WebGPU runtime.</p>
                <p style="font-size:11px;color:#f1d79a">No parameters to tune. Analysis covers the whole selected model; ROI/density scope limits final candidates. Review Candidates/Cleaned before export.</p>
              </fieldset>
            </details>
            <p id="sc-counts" style="white-space:pre-wrap;font-size:12px;margin:10px 0"></p>
          </div>
        </div>
        <div id="sc-footer" hidden style="flex:none;border-top:1px solid #535b64;margin-top:8px;padding-top:8px">
          <div style="display:flex;gap:7px;flex-wrap:wrap;align-items:center">
            <label>View <select id="sc-view"><option value="original">Original</option><option value="candidates">Candidates</option><option value="cleaned">Cleaned</option></select></label>
            <label><input type="checkbox" id="sc-isolate"> Isolate scope</label>
            <button id="sc-apply" type="button">Apply / Preview</button>
          </div>
          <div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap;margin-top:7px">
            <select id="sc-format"><option value="ply">PLY / Compressed PLY</option><option value="splat">SPLAT</option><option value="sog">SOG</option><option value="spz">SPZ</option></select>
            <button id="sc-export" type="button" disabled title="Apply a nonempty removal selection first">Export Cleaned…</button>
            <button id="sc-restore" type="button">Restore</button>
          </div>
        </div></div>`;
}
    function axisMarkup(axis) {
        const cap=axis.toUpperCase();
        return `<div style="margin:9px 0;padding:9px;background:#303135;border:1px solid #505158;border-radius:7px">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
            <strong>${cap} Axis</strong><span id="sc-${axis}-domain" style="font-size:11px;color:#c7c7c7"></span>
          </div>
          <div style="display:grid;grid-template-columns:88px minmax(0,1fr) 88px;gap:9px;align-items:center">
            <label style="font-size:12px;min-width:0">Min
              <input id="sc-${axis}-min" type="number" step="0.001" aria-label="${cap} minimum"
                style="display:block;margin-top:5px;width:100%;min-width:0;box-sizing:border-box;background:#222;color:#fff;border:1px solid #777;border-radius:5px;padding:5px 3px;font:inherit">
            </label>
            <div id="sc-${axis}-slider" role="group" aria-label="${cap} interval"
              style="position:relative;height:34px;margin:10px 11px 0;touch-action:none;user-select:none;cursor:pointer;min-width:0">
              <div style="position:absolute;left:0;right:0;top:14px;height:6px;border-radius:3px;background:#60646a;pointer-events:none"></div>
              <div id="sc-${axis}-selected" style="position:absolute;top:14px;height:6px;background:#77b6f8;cursor:grab;touch-action:none;z-index:1"></div>
              <button id="sc-${axis}-min-handle" data-handle="min" type="button" role="slider" aria-label="Minimum ${cap}"
                style="position:absolute;top:6px;left:0;width:22px;height:22px;border-radius:50%;border:2px solid #d9e8ff;background:#357dc8;transform:translateX(-50%);cursor:ew-resize;touch-action:none;z-index:3;padding:0"></button>
              <button id="sc-${axis}-max-handle" data-handle="max" type="button" role="slider" aria-label="Maximum ${cap}"
                style="position:absolute;top:6px;left:100%;width:22px;height:22px;border-radius:50%;border:2px solid #d9e8ff;background:#357dc8;transform:translateX(-50%);cursor:ew-resize;touch-action:none;z-index:4;padding:0"></button>
            </div>
            <label style="font-size:12px;min-width:0">Max
              <input id="sc-${axis}-max" type="number" step="0.001" aria-label="${cap} maximum"
                style="display:block;margin-top:5px;width:100%;min-width:0;box-sizing:border-box;background:#222;color:#fff;border:1px solid #777;border-radius:5px;padding:5px 3px;font:inherit">
            </label>
          </div>
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;margin-top:7px">
            <span id="sc-${axis}-current" style="font-size:11px;color:#aad4ff"></span>
            <button type="button" id="sc-${axis}-reset">Reset</button>
          </div>
        </div>`;
    }

export async function activate({editor,uiHost}) {
    const scene=window.scene;
    assert(scene?.elements && scene?.events && scene?.commandQueue && uiHost,
        'Splat Cleaner requires audited internal scene and a Plugin Manager UI host.');
    assert(scene.events.functions?.has('scene.write') && scene.events.functions?.has('show.exportPopup'),
        'Native Editor export services unavailable.');
    let panel=null, windowControls=null, selected=null, stopped=false, failure=null, busy=false, generation=0;
    let data=null,density=null,components=null,roiRanges=null,choice=null,preview=null,isolation=null,originalColor=null,lockedColor=null;
    let stMask=null, stDetails=null, snsMask=null, snsDetails=null, gpuUnavailable=false, analysisIdentity=null;
    let restoreError=null, activeExport=false, selectionRestoring=false, analyzedOpacityEncoding=null;
    let pipeline=Promise.resolve();
    const tasks=new Set();
    const track = promise => { tasks.add(promise); void promise.then(()=>tasks.delete(promise),()=>tasks.delete(promise)); return promise; };
    const queue = fn => { pipeline=pipeline.catch(()=>{}).then(()=>scene.commandQueue.enqueue(fn)); return pipeline; };
    const get=id=>panel?.querySelector(`#${id}`);
    const status=text => { if(panel) get('sc-progress').textContent=text; };
    const valid = () => !stopped && selected && modelAttached(scene,selected);
    const snsParameters=()=>validatedSnsParameters(get('sc-sns-k').value,get('sc-sns-m').value);
    // Avoid retaining duplicate million-element instance arrays just for cache
    // checks. Identity + world/palette transforms catch common Editor edits;
    // in-place source-row or flag edits still require an explicit Analyze.
    const analysisCurrent=()=>{
        if(!data || !analysisIdentity || !valid() || selected!==analysisIdentity.model ||
            selected.instances!==analysisIdentity.instances || selected.resource.source!==analysisIdentity.source ||
            selected.instances.count!==data.centers.x.length ||
            !selected.worldTransform.equals(analysisIdentity.world))return false;
        for(const [id,matrix] of data.transformMap)
            if(!transformOf(selected,id).equals(matrix))return false;
        return true;
    };
    function invalidateSnsSettings() {
        let params;
        try {params=snsParameters();} catch (_) {params=null;}
        if(snsDetails && (!params || snsDetails.k!==params.k || snsDetails.min_neighbors!==params.m)) {
            const enabled=get('sc-sns-enabled').checked;
            snsMask=null; snsDetails=null;
            get('sc-sns-enabled').checked=false;
            get('sc-sns-enabled').disabled=true;
            get('sc-sns-status').textContent='SNS settings changed. Click Analyze SNS again; GPU result is retained.';
            if(enabled)invalidateAppliedSelection('SNS settings changed.');
            else status('SNS result marked stale. Other enabled rules and their previews are unchanged.');
        } else if(!params && get('sc-sns-enabled').checked) {
            invalidateAppliedSelection('Enter valid SNS k and m values.');
        }
    }

    const clearCache=()=>{
        data=null;density=null;components=null;roiRanges=null;choice=null;analyzedOpacityEncoding=null;stMask=null;stDetails=null;snsMask=null;snsDetails=null;analysisIdentity=null;
        if(panel) {
            get('sc-controls').hidden=true;get('sc-footer').hidden=true;
            get('sc-floater-enabled').checked=false;get('sc-floater-enabled').disabled=true;
            get('sc-component-select').replaceChildren(new Option('None — analyze first',''));get('sc-component-select').disabled=true;
            get('sc-component-status').textContent='Not calculated. Optional; runs only when requested.';
            get('sc-sns-enabled').checked=false;get('sc-sns-enabled').disabled=true;
            get('sc-sns-status').textContent='Not analyzed. Click Analyze SNS with the current k/m values.';
            get('sc-st-enabled').checked=false;get('sc-st-enabled').disabled=true;
            get('sc-st-status').textContent='Not analyzed. Automatic voxel sizing; bundled SplatTransform GPU runtime required.';
        }
    };
    async function restore() {
        if (!preview && !isolation && !originalColor) return;
        const errors=[];
        try {
            await queue(()=>{
                // Do not write GPU state of a detached/destroyed model.
                if (preview && modelAttached(scene,preview.splat)) {
                    try { preview.restore(scene); } catch(e) {
                        errors.push(showError(e));
                        if (/device.{0,35}lost|GPUBuffer|DEVICE_HUNG|DEVICE_REMOVED|writeBuffer/i.test(showError(e)))
                            gpuUnavailable=true;
                    }
                }
                if (lockedColor && originalColor) lockedColor.copy(originalColor);
                scene.forceRender=true;
            });
        } catch(e) { errors.push(`Native restoration: ${showError(e)}`); }
        try { isolation?.restore(); } catch(e) { errors.push(`Model visibility: ${showError(e)}`); }
        preview=null; isolation=null; lockedColor=null; originalColor=null; choice=null;updateExportReadiness();
        if (errors.length) {
            restoreError=errors.join('; ');
            throw new Error(`Preview restoration uncertain: ${restoreError}`);
        }
        if(!gpuUnavailable)restoreError=null;
    }
    function refreshModels() {
        if(!panel) return;
        const models=loadedSplats(scene);
        if(!models.includes(selected)) { selected=models.length===1?models[0]:null; clearCache(); }
        const select=get('sc-model');
        select.replaceChildren();
        const add=(text,value)=>{ const option=document.createElement('option'); option.textContent=text;option.value=value;select.append(option); };
        add(models.length?'Choose model…':'No 3DGS models','');
        models.forEach((m,i)=>add(`${m.name||'(unnamed)'} (#${i+1})${m.visible?'':' [hidden]'}`,String(i)));
        select.value=selected?String(models.indexOf(selected)):'';
        select.disabled=busy;
        get('sc-analyze').disabled=busy || !selected;
        get('sc-sns-find').disabled=busy || !selected;
        get('sc-st-find').disabled=busy || !selected;
    }
    function refreshAttributeUI() {
        if(!data) return;
        const sizeOK=!!data.sizes, opacityOK=!!data.opacities;
        const size=get('sc-size-enabled'), opacity=get('sc-opacity-enabled');
        size.disabled=!sizeOK; opacity.disabled=!opacityOK;
        if(!sizeOK) size.checked=false;
        if(!opacityOK) opacity.checked=false;
        get('sc-size-p').disabled=!sizeOK;
        get('sc-opacity').disabled=!opacityOK;
        get('sc-attributes').textContent=`Size: ${data.attributeStatus.size}. Opacity: ${data.attributeStatus.opacity}. SNS reads covariance separately when requested.`;
    }
    function invalidateAppliedSelection(message) {
        choice=null;updateExportReadiness();
        get('sc-counts').textContent='Selection settings changed. Click Apply / Preview to refresh candidate and retained counts.';
        if (!preview && !isolation) {status(message);return;}
        get('sc-view').value='original';
        if (selectionRestoring) return;
        if (busy || activeExport) {status('Finish current operation, Restore preview, then Apply updated rules.');return;}
        busy=true;selectionRestoring=true;
        track((async()=>{
            try {
                await restore();
                get('sc-view').value='original';
                status(`${message} Previous preview restored; click Apply / Preview.`);
            } catch(e) {failure=e;status(`Previous preview could not be restored: ${showError(e)}`);}
            finally {selectionRestoring=false;busy=false;refreshModels();updateExportReadiness();}
        })());
    }
    function markRoiChanged() {
        invalidateAppliedSelection('XYZ region changed.');
    }
    function syncAxis(axis) {
        const d=density.bounds[axis], r=roiRanges[axis], span=d.max-d.min;
        const ratio=value => span>0 ? clamp((value-d.min)/span,0,1) : 0.5;
        const minPct=100*ratio(r.min), maxPct=100*ratio(r.max);
        get(`sc-${axis}-min`).value=display3(r.min);
        get(`sc-${axis}-max`).value=display3(r.max);
        get(`sc-${axis}-domain`).textContent=`Full ${axis.toUpperCase()}: ${display3(d.min)} to ${display3(d.max)}`;
        get(`sc-${axis}-current`).textContent=`Selected ${axis.toUpperCase()}: ${display3(r.min)} to ${display3(r.max)}`;
        get(`sc-${axis}-selected`).style.left=`${minPct}%`;
        get(`sc-${axis}-selected`).style.width=`${Math.max(0,maxPct-minPct)}%`;
        const together=Math.abs(maxPct-minPct)<0.01;
        for(const side of ['min','max']) {
            const handle=get(`sc-${axis}-${side}-handle`);
            handle.style.left=`${side==='min'?minPct:maxPct}%`;
            handle.style.transform=together
                ? `translateX(calc(-50% ${side==='min'?'-':'+'} 7px))` : 'translateX(-50%)';
            handle.setAttribute('aria-valuemin',String(side==='min'?d.min:r.min));
            handle.setAttribute('aria-valuemax',String(side==='min'?r.max:d.max));
            handle.setAttribute('aria-valuenow',String(r[side]));
            handle.setAttribute('aria-valuetext',`${display3(r[side])} model units`);
        }
    }
    function setAxisEndpoint(axis, side, value) {
        if(!density || !roiRanges || (busy && !selectionRestoring) || activeExport)return;
        const next=reviseRoiInterval(roiRanges[axis],density.bounds[axis],side,value);
        if(next.min!==roiRanges[axis].min || next.max!==roiRanges[axis].max) {
            roiRanges[axis]=next;markRoiChanged();
        }
        syncAxis(axis);
    }
    function bindAxis(axis) {
        const slider=get(`sc-${axis}-slider`),domain=density.bounds[axis];
        const positionToValue=x=>{
            const rect=slider.getBoundingClientRect();
            if(rect.width<=0 || domain.max===domain.min)return domain.min;
            return round3(domain.min+clamp((x-rect.left)/rect.width,0,1)*(domain.max-domain.min));
        };
        for(const side of ['min','max']) {
            const input=get(`sc-${axis}-${side}`);
            input.addEventListener('change',()=>{
                const value=Number(input.value);
                if(input.value.trim()==='' || !Number.isFinite(value)) {
                    status(`Invalid ${axis.toUpperCase()} coordinate. Enter a finite number.`);syncAxis(axis);return;
                }
                setAxisEndpoint(axis,side,round3(value));
            });
            get(`sc-${axis}-${side}-handle`).addEventListener('keydown',e=>{
                const old=roiRanges?.[axis]?.[side];
                if(old===undefined)return;
                const step=e.shiftKey?0.01:0.001;
                const value=e.key==='Home'?domain.min:e.key==='End'?domain.max:
                    e.key==='ArrowLeft'||e.key==='ArrowDown'?round3(old-step):
                    e.key==='ArrowRight'||e.key==='ArrowUp'?round3(old+step):null;
                if(value===null)return;
                e.preventDefault();setAxisEndpoint(axis,side,value);
            });
        }
        get(`sc-${axis}-reset`).onclick=()=>{
            if(!density || (busy && !selectionRestoring) || activeExport)return;
            roiRanges[axis]={...domain};syncAxis(axis);markRoiChanged();
        };
        let drag=null;
        slider.addEventListener('pointerdown',e=>{
            if(!roiRanges || (busy && !selectionRestoring) || activeExport || e.button!==0)return;
            const target=e.target;
            const handle=target?.closest?.('[data-handle]');
            const selectedTrack=target?.id===`sc-${axis}-selected`;
            const r=roiRanges[axis], value=positionToValue(e.clientX);
            let side=handle?.dataset.handle;
            if(!side && !selectedTrack) {
                side=Math.abs(value-r.min)<=Math.abs(value-r.max)?'min':'max';
                setAxisEndpoint(axis,side,value);
            }
            drag={id:e.pointerId,side:side??'range',startX:e.clientX,startRange:{...roiRanges[axis]}};
            slider.setPointerCapture(e.pointerId);
            e.preventDefault();
        });
        slider.addEventListener('pointermove',e=>{
            if(!drag || drag.id!==e.pointerId || !roiRanges)return;
            if(drag.side!=='range') {setAxisEndpoint(axis,drag.side,positionToValue(e.clientX));return;}
            const width=slider.getBoundingClientRect().width;
            if(width<=0)return;
            let delta=(e.clientX-drag.startX)/width*(domain.max-domain.min);
            delta=clamp(delta,domain.min-drag.startRange.min,domain.max-drag.startRange.max);
            const next={min:drag.startRange.min+delta,max:drag.startRange.max+delta};
            if(next.min!==roiRanges[axis].min || next.max!==roiRanges[axis].max) {
                roiRanges[axis]=next;markRoiChanged();syncAxis(axis);
            }
        });
        const endDrag=e=>{
            if(!drag || drag.id!==e.pointerId)return;
            drag=null;
            if(slider.hasPointerCapture(e.pointerId))slider.releasePointerCapture(e.pointerId);
        };
        slider.addEventListener('pointerup',endDrag);
        slider.addEventListener('pointercancel',endDrag);
    }
    function initializeBounds() {
        if(!density)return;
        roiRanges=Object.fromEntries(AXES.map(axis=>[axis,{...density.bounds[axis]}]));
        get('sc-roi').innerHTML=AXES.map(axisMarkup).join('');
        for(const axis of AXES){bindAxis(axis);syncAxis(axis);}
    }
    function readConfig() {
        assert(density && data && roiRanges,'Analyze before selecting a cleaning region.');
        if(get('sc-opacity-enabled').checked || get('sc-st-enabled').checked)
            assert(get('sc-opacity-encoding').value===analyzedOpacityEncoding,
                'Opacity encoding changed; click Analyze before applying opacity or GPU rules.');
        if(get('sc-st-enabled').checked)
            assert(stMask && stDetails, 'Run automatic GPU floater analysis before applying this rule.');
        if(get('sc-sns-enabled').checked) {
            assert(snsMask && snsDetails, 'Run SNS analysis before applying this rule.');
            const {k,m}=snsParameters();
            assert(snsDetails.k===k && snsDetails.min_neighbors===m, 'SNS settings changed; click Analyze SNS again.');
        }
        // Use full-precision internal endpoints: rounded displayed model bounds
        // must not accidentally exclude a few boundary Gaussians.
        const roi=Object.fromEntries(AXES.map(axis=>[axis,{...roiRanges[axis]}]));
        const percentile=Number(get('sc-size-p').value),opacity=Number(get('sc-opacity').value);
        assert(percentile>=1 && percentile<=100 && Number.isFinite(percentile), 'Size percentile must be from 1 to 100.');
        assert(opacity>=0 && opacity<=1 && Number.isFinite(opacity), 'Opacity threshold must be from 0 to 1.');
        for(const a of AXES) assert(Number.isFinite(roi[a].min) && Number.isFinite(roi[a].max) && roi[a].min<=roi[a].max,
            `Invalid ${a.toUpperCase()} region bounds.`);
        const maxComponentGaussians=Number(get('sc-component-max').value);
        if(get('sc-floater-enabled').checked)
            assert(Number.isInteger(maxComponentGaussians) && maxComponentGaussians>=1 && maxComponentGaussians<=100000,
                'Maximum candidate-component size must be an integer from 1 to 100000.');
        const snsParams=get('sc-sns-enabled').checked?snsParameters():{k:null,m:null};
        return {roi,density:get('sc-density').value,snsK:snsParams.k,snsMinNeighbors:snsParams.m,
            floaterEnabled:get('sc-floater-enabled').checked,maxComponentGaussians,
            selectedComponentId:get('sc-component-select').value===''?null:Number(get('sc-component-select').value),
            sizeEnabled:get('sc-size-enabled').checked, sizePercentile:percentile,
            snsEnabled:get('sc-sns-enabled').checked,
            opacityEnabled:get('sc-opacity-enabled').checked,opacityThreshold:opacity,
            opacityEncoding:get('sc-opacity-encoding').value,
            splatTransformEnabled:get('sc-st-enabled').checked};
    }
    async function applyPreview(reuseSelection=false) {
        assert(valid() && data && density && analysisCurrent(), 'Model or transforms changed; click Analyze again.');
        assert(!gpuUnavailable, 'GPU device is unavailable after a failed upload/filter; reload the Editor before preview.');
        assert(!document.getElementById('custom-xyz-preview'),
            'Close XYZ Filter preview before using Splat Cleaner (both modify native visibility).');
        // View changes reuse the last applied selection: View changes display only,
        // and must not silently recompute masks from edited filter controls.
        const config=reuseSelection && choice ? choice.config : readConfig();
        // Compute candidate state first. An exception cannot partially alter GPU visibility.
        const selection=reuseSelection && choice ? choice.selection :
            computeSelection(data.centers,density,config,{sizes:data.sizes,opacity:data.opacities,components,splatTransformMask:stMask,snsMask});
        const hidden=previewHidden(selection,get('sc-view').value,get('sc-isolate').checked);
        // Initial Original view does not require native GPU flag writes.
        if (!preview && !isolation && !get('sc-isolate').checked && get('sc-view').value==='original') {
            choice={config,selection};updateExportReadiness();
            get('sc-counts').textContent=`Original: ${data.centers.x.length.toLocaleString()} | Candidates: ${selection.candidateCount.toLocaleString()} | Retained: ${selection.retainedCount.toLocaleString()}\nOriginal view needs no GPU preview upload.`;
            status('Selection calculated. Choose Candidates/Cleaned to inspect it, or export the current applied selection.');
            return;
        }
        await queue(()=>{
            assert(valid(), 'Model removed while applying cleaning preview.');
            if (!preview) {
                lockedColor=scene.events.invoke('lockedClr');
                assert(lockedColor?.clone && lockedColor?.copy,'Native locked-color service unavailable.');
                originalColor=lockedColor.clone();
                preview=new Preview(selected,data);
            }
            // Unrelated models remain visible in unfiltered Original mode.
            // While masking, isolate them to avoid changing their locked-color rendering.
            if(hidden.some(v=>v!==0)) {
                if(!isolation) isolation=isolationFor(scene,selected);
                else isolation.ensure();
            } else if(isolation) { isolation.restore();isolation=null; }
            preview.verify(scene);
            lockedColor.a=hidden.some(v=>v!==0) ? 0 : originalColor.a;
            preview.setHidden(scene,hidden);
        });
        choice={config,selection};updateExportReadiness();
        get('sc-counts').textContent=`Original: ${data.centers.x.length.toLocaleString()}  |  ROI/density scope: ${selection.scopedCount.toLocaleString()}\n`+
            `Candidates: ${selection.candidateCount.toLocaleString()}  |  Retained: ${selection.retainedCount.toLocaleString()}\n`+
            `By rule — size ${selection.ruleCounts.size}, opacity ${selection.ruleCounts.opacity}, SNS ${selection.ruleCounts.sns}, components ${selection.ruleCounts.floaters}, SplatTransform ${selection.ruleCounts.splatTransformFloaters}`+
            (config.snsEnabled&&config.splatTransformEnabled?`\nSNS ∩ GPU: ${selection.snsGpuOverlap} (overlap counted once)`:'')+
            (config.floaterEnabled?`\nSelected disconnected groups in scope: ${selection.selectedFloaterComponents}`:'')+
            (selection.sizeResolvedThreshold!==null?`\nResolved size threshold: ${selection.sizeResolvedThreshold.toPrecision(5)}`:'')+
            `\nNo permanent deletion. Native preview temporarily hides Gaussian instances.`;
        status(selection.candidateCount === 0
            ? 'No removal candidates. Enable a cleaning rule (SNS, opacity, components or SplatTransform), then Apply / Preview.'
            : selection.retainedCount === 0
                ? 'All Gaussians selected: review thresholds. Export requires at least one retained Gaussian.'
                : 'Preview applied. Inspect Candidates/Cleaned before exporting.');
    }
    async function doAnalyze() {
        assert(!busy && selected && valid(), 'Select a visible loaded model first.');
        busy=true; const token=++generation;
        clearCache();
        refreshModels();
        const started=performance.now();
        const modelBefore=selected, instancesBefore=selected.instances, sourceBefore=selected.resource.source,
            worldBefore=selected.worldTransform.clone(), countBefore=selected.instances.count;
        try {
            await restore();
            status('Reading Gaussian positions and attributes…');
            data=await readModel(selected,()=>stopped || token!==generation,
                (done,total)=>status(`Reading attributes… ${Math.round(done/total*100)}%`),
                {opacityEncoding:get('sc-opacity-encoding').value});
            assert(!stopped && token===generation && valid() && selected===modelBefore &&
                selected.instances===instancesBefore && selected.resource.source===sourceBefore &&
                selected.instances.count===countBefore && selected.worldTransform.equals(worldBefore),
                'Analysis cancelled: model/source/transform changed.');
            for(const [palette,matrix] of data.transformMap) assert(transformOf(selected,palette).equals(matrix),
                'Palette transforms changed during analysis.');
            density=await analyzeDensity(data.centers,{ resolution:64,
                cancelled:()=>stopped || token!==generation || !valid(),
                progress:(done,total)=>status(`Computing voxel density… ${Math.round(done/total*100)}%`) });
            assert(!stopped && token===generation && valid() && selected===modelBefore &&
                selected.instances===instancesBefore && selected.resource.source===sourceBefore &&
                selected.instances.count===countBefore && selected.worldTransform.equals(worldBefore),
                'Analysis cancelled: model/source/transform changed.');
            analyzedOpacityEncoding=get('sc-opacity-encoding').value;
            analysisIdentity={model:selected,instances:selected.instances,source:selected.resource.source,world:selected.worldTransform.clone()};
            initializeBounds();refreshAttributeUI(); get('sc-controls').hidden=false;get('sc-footer').hidden=false;
            get('sc-counts').textContent=`Density distribution — Sparse ${density.classCounts[0].toLocaleString()}, `+
                `Medium ${density.classCounts[1].toLocaleString()}, Dense ${density.classCounts[2].toLocaleString()}\n`+
                `Occupied voxel cells: ${density.occupiedCells.toLocaleString()}, cutoffs: ${density.cutoffs.join(' / ')}.`;
            status(`Analyzed ${data.centers.x.length.toLocaleString()} Gaussian instances in ${((performance.now()-started)/1000).toFixed(2)}s. Density classes are not quality labels.`);
        } catch(e) {
            clearCache(); status(`Analysis unavailable: ${showError(e)}`);
        } finally { busy=false;refreshModels();updateExportReadiness(); }
    }
    function updateExportReadiness() {
        if (!panel) return;
        const ready=!!(choice && choice.selection.candidateCount>0 && choice.selection.retainedCount>0 && valid() && analysisCurrent() && !gpuUnavailable && !busy && !activeExport);
        const button=get('sc-export');
        button.disabled=!ready;
        button.title=ready ? 'Export selected model after excluding approved candidates' :
            'Select candidates and click Apply / Preview before exporting';
    }
    function populateComponentOptions() {
        const select=get('sc-component-select');
        select.replaceChildren(new Option('None — small groups only or no floater selection',''));
        if(!components) {select.disabled=true;return;}
        // Surface the most significant detached components, not just tiny fragments.
        // Preserve the main component even if the user attempts to set its ID.
        const others=Array.from({length:components.sizes.length},(_,id)=>id)
            .filter(id=>id!==components.largestId)
            .sort((a,b)=>components.sizes[b]-components.sizes[a] || a-b)
            .slice(0,20);
        for(const id of others)
            select.append(new Option(`Group ${id+1}: ${components.sizes[id].toLocaleString()} splats (${components.cellCounts[id]} cells)`,String(id)));
        select.disabled=others.length===0;
    }
    function updateComponentSummary() {
        if(!components || !panel) return;
        const max=Number(get('sc-component-max').value);
        if(!Number.isInteger(max) || max<1 || max>100000) {
            get('sc-component-status').textContent='Enter a component limit from 1 to 100000.';
            return;
        }
        let small=0,n=0;
        for(let id=0;id<components.sizes.length;id++) {
            if(id!==components.largestId && components.sizes[id]<=max) {small++;n+=components.sizes[id];}
        }
        const sorted=[...components.sizes].sort((a,b)=>b-a);
        get('sc-component-status').textContent=`${components.componentCount.toLocaleString()} components; largest: ${components.sizes[components.largestId].toLocaleString()} Gaussians.\n`+
            `Next detached groups: ${sorted.slice(1,4).map(v=>v.toLocaleString()).join(' / ') || 'none'} Gaussians.\n`+
            `${small.toLocaleString()} small groups (${n.toLocaleString()} Gaussians) at current size limit, before ROI filtering.\n`+
            `Voxel width: ${display3(components.voxelWidth)} world units. ${components.coarseningPasses?'Grid coarsened to cap work.':''}`;
    }
    async function doFindComponents() {
        assert(!busy && !activeExport && density && data && valid(), 'Analyze a valid model first.');
        busy=true;const token=++generation;
        const model=selected,instances=selected.instances,source=selected.resource.source;
        const world=selected.worldTransform.clone();
        try {
            await restore();
            status('Finding disconnected occupied-voxel components…');
            const result=await analyzeComponents(data.centers,{
                cancelled:()=>stopped || token!==generation || !valid(),
                progress:(phase,done,total)=>status(`Component ${phase}: ${Math.round(done/Math.max(total,1)*100)}%`)
            });
            assert(!stopped && token===generation && valid() && selected===model &&
                selected.instances===instances && selected.resource.source===source &&
                selected.worldTransform.equals(world), 'Model changed during component detection; reanalyze.');
            for(const [palette,matrix] of data.transformMap)
                assert(transformOf(selected,palette).equals(matrix),'Palette transforms changed; reanalyze.');
            components=result;choice=null;updateExportReadiness();
            get('sc-floater-enabled').disabled=false;populateComponentOptions();
            updateComponentSummary();
            status('Components found. Tick Select small components OR choose a specific detached group, then Apply / Preview. No geometry deleted.');
        } catch(e) {
            components=null;get('sc-floater-enabled').checked=false;get('sc-floater-enabled').disabled=true;
            get('sc-component-select').replaceChildren(new Option('None — analyze first',''));get('sc-component-select').disabled=true;
            get('sc-component-status').textContent=`Unavailable: ${showError(e)}`;
            status(`Component analysis unavailable: ${showError(e)}`);
        } finally {busy=false;refreshModels();updateExportReadiness();}
    }
    async function doSnsSupport() {
        assert(!busy && !activeExport && valid(), 'Select a visible model first.');
        if(!data || !density) await doAnalyze();
        assert(!busy && data && density && analysisCurrent(), 'Model data or transforms changed; click Analyze before SNS.');
        const {k,m}=snsParameters();
        if(snsMask && snsDetails?.k===k && snsDetails?.min_neighbors===m) {
            status(`SNS result already calculated (k=${k}, m=${m}). Toggle its rule and Apply / Preview.`);
            return;
        }
        busy=true; const token=++generation;
        const model=selected, instances=model.instances, source=model.resource.source, world=model.worldTransform.clone();
        const rows=instances.sourceRow.slice(), palette=instances.palette.slice();
        snsMask=null;snsDetails=null;
        get('sc-sns-enabled').checked=false;get('sc-sns-enabled').disabled=true;
        try {
            await restore();
            const cancelled=()=>stopped || token!==generation || !valid() || selected!==model;
            const geometry=await readSnsGeometry(model,data,{k,cancelled,
                progress:(done,total)=>status(`Reading SNS geometry… ${Math.round(done/total*100)}%`)});
            assert(!cancelled() && model.instances===instances && model.resource.source===source &&
                model.worldTransform.equals(world), 'Model changed during SNS analysis.');
            for(let i=0;i<rows.length;i++)
                assert(rows[i]===instances.sourceRow[i] && palette[i]===instances.palette[i],
                    'Instance/source mapping changed during SNS analysis.');
            for(const [id,matrix] of data.transformMap)
                assert(transformOf(model,id).equals(matrix), 'Palette transform changed during SNS analysis.');
            status('Evaluating scale-normalized local center support…');
            const result=await analyzeSnsSupport(data.centers,geometry,{k,minSupport:m,cancelled,
                progress:(done,total)=>status(`Evaluating SNS… ${Math.round(done/total*100)}%`)});
            assert(!cancelled() && model.instances===instances && model.resource.source===source &&
                model.worldTransform.equals(world), 'Model changed during SNS neighborhood search.');
            for(let i=0;i<rows.length;i++)
                assert(rows[i]===instances.sourceRow[i] && palette[i]===instances.palette[i],
                    'Instance/source mapping changed during SNS neighborhood search.');
            for(const [id,matrix] of data.transformMap)
                assert(transformOf(model,id).equals(matrix), 'Palette transform changed during SNS neighborhood search.');
            assert(snsParameters().k===k && snsParameters().m===m, 'SNS parameters changed during analysis.');
            snsMask=result.candidateMask;
            snsDetails={method:'oriented_ellipsoid_center_support',k,min_neighbors:m,
                analysis_scope:'entire_selected_model',candidates_before_xyz_density_scope:result.candidateCount,
                supported:result.supportedCount,inconclusive:result.inconclusiveCount,
                invalid:result.invalidCount,locked_excluded:result.lockedExcluded,
                spatial_index_cell_width:result.cellWidth,
                limitations:'Center support only; neither Gaussian overlap nor actual rendered contribution.'};
            get('sc-sns-enabled').disabled=false;
            // Analysis never implicitly enables a cleaning rule.
            get('sc-rules-details').open=true;
            get('sc-sns-status').textContent=`SNS: ${result.candidateCount.toLocaleString()} candidate(s), `+
                `${result.supportedCount.toLocaleString()} supported, ${result.inconclusiveCount.toLocaleString()} inconclusive; `+
                `${result.lockedExcluded.toLocaleString()} original locked instances protected. k=${k}, m=${m}. Enable rule then Apply / Preview.`;
            status(`SNS calculated (k=${k}, m=${m}). Enable the SNS rule to include its candidates.`);
        }catch(e){
            snsMask=null;snsDetails=null;
            get('sc-sns-enabled').checked=false;get('sc-sns-enabled').disabled=true;
            get('sc-sns-status').textContent=`Unavailable: ${showError(e)}`;
            status(`SNS analysis unavailable: ${showError(e)}`);
        }finally{busy=false;refreshModels();updateExportReadiness();}
    }
    async function doSplatTransformFloaters() {
        assert(!busy && !activeExport && valid(), 'Select a valid visible model first.');
        // One-click operation: populate standard v0.2.6 analysis when it is not cached.
        if(!data || !density) await doAnalyze();
        assert(!busy && data && density && analysisCurrent(), 'Model data or transforms changed; click Analyze before GPU floaters.');
        assert(get('sc-opacity-encoding').value===analyzedOpacityEncoding,
            'Opacity encoding changed; click Analyze before GPU Floaters.');
        assert(!gpuUnavailable, 'A previous GPU failure requires Editor reload before GPU floater analysis.');
        if(stMask && stDetails) {status('GPU Floaters result cached. Enable its rule, then Apply / Preview.');return;}
        // Prevent the known unvalidated 8.9M-scene GPU failure from taking
        // down SuperSplat. Reevaluate only after live workload validation.
        assert(selected.instances.count<=MAX_UNVALIDATED_GPU_FLOATERS,
            `GPU Floaters are disabled for >${MAX_UNVALIDATED_GPU_FLOATERS.toLocaleString()} instances pending device-stability validation. CPU SNS remains available.`);
        busy=true; const token=++generation;
        const model=selected, instances=model.instances, source=model.resource.source, world=model.worldTransform.clone();
        const rows=instances.sourceRow.slice(), palette=instances.palette.slice();
        stMask=null;stDetails=null;
        get('sc-st-enabled').checked=false;get('sc-st-enabled').disabled=true;
        try {
            await restore();
            // Fail fast when the local runtime has not been bundled; do not read millions of source rows first.
            const bridge=await loadSplatTransformBridge();
            status('Reading SplatTransform geometric attributes…');
            const cancelled=()=>stopped || token!==generation || !valid() || selected!==model;
            const columns=await readFloaterColumns(model,data,{
                cancelled,opacityEncoding:analyzedOpacityEncoding,
                progress:(done,total)=>status(`Reading floater geometry… ${Math.round(done/total*100)}%`)
            });
            assert(!cancelled() && model.instances===instances && model.resource.source===source &&
                model.worldTransform.equals(world), 'Model changed during SplatTransform analysis.');
            for (let i=0;i<rows.length;i++)
                assert(rows[i]===instances.sourceRow[i] && palette[i]===instances.palette[i],
                    'Instance/source mapping changed during SplatTransform analysis.');
            for (const [id,matrix] of data.transformMap)
                assert(transformOf(model,id).equals(matrix), 'Palette transform changed; reanalyze.');
            const auto=autoVoxelResolution(columns);
            const {voxelResolution,opacityCutoff,minContribution}=auto;
            const parameters={voxelResolution,opacityCutoff,minContribution};
            status(`Running SplatTransform GPU floaters (automatic voxel width ${voxelResolution.toPrecision(4)})…`);
            const candidate=await runSplatTransformFloaters(columns,parameters,()=>Promise.resolve(bridge));
            assert(!cancelled() && model.instances===instances && model.resource.source===source &&
                model.worldTransform.equals(world), 'Model changed during GPU floater analysis.');
            for (let i=0;i<rows.length;i++)
                assert(rows[i]===instances.sourceRow[i] && palette[i]===instances.palette[i],
                    'Instance/source mapping changed during GPU floater analysis.');
            for (const [id,matrix] of data.transformMap)
                assert(transformOf(model,id).equals(matrix), 'Palette transform changed during GPU floater analysis.');
            assert(analyzedOpacityEncoding===get('sc-opacity-encoding').value,
                'Opacity encoding changed during GPU analysis.');
            stMask=candidate;
            const total=candidate.reduce((a,v)=>a+v,0);
            stDetails={method:`splat_transform_${bridge.splatTransformVersion || 'unknown'}_filterFloaters`,runtime_version:bridge.splatTransformVersion || null,parameters,automatic_voxel_sizing:auto,
                analysis_scope:'entire_selected_model',candidates_before_xyz_density_scope:total,
                limitations:'GPU voxel-contribution test; not guaranteed to remove internally supported detached clusters'};
            get('sc-st-enabled').disabled=false;
            // Analysis never implicitly enables a cleaning rule.
            get('sc-st-details').open=true;
            get('sc-st-status').textContent=`Analyzed ${candidate.length.toLocaleString()} instances. ${total.toLocaleString()} candidate(s) before scope. Automatic voxel width: ${voxelResolution.toPrecision(5)} world units; median middle scale: ${auto.medianMiddleScale.toPrecision(5)}. Click Apply / Preview to inspect.`;
            status('GPU floaters calculated. Enable its rule and click Apply / Preview to review.');
        } catch(e) {
            if (/device.{0,35}lost|GPUBuffer|DEVICE_HUNG|DEVICE_REMOVED|mapAsync/i.test(showError(e))) gpuUnavailable=true;
            stMask=null;stDetails=null;
            get('sc-st-enabled').checked=false;get('sc-st-enabled').disabled=true;
            get('sc-st-status').textContent=`Unavailable: ${showError(e)}`;
            status(`SplatTransform floater analysis unavailable: ${showError(e)}`);
        } finally {busy=false;refreshModels();updateExportReadiness();}
    }
    async function doExport() {
        assert(choice && choice.selection.candidateCount>0 && choice.selection.retainedCount>0 && valid() && analysisCurrent(),
            'Export requires a current applied selection and an unchanged model.');
        assert(!activeExport && !busy && !gpuUnavailable, 'Finish current operations or reload the Editor after a GPU failure.');
        assert(scene.events.functions?.has('scene.write') && scene.events.functions?.has('show.exportPopup'), 'Native exporter unavailable.');
        // Begin browser-gesture-sensitive directory request before ANY await.
        const directoryPromise=window.showDirectoryPicker ? scene.events.invoke('scene.getExportDirectory') : undefined;
        activeExport=true;busy=true;
        const model=selected, frozenChoice=choice;
        const format=get('sc-format').value;
        const controls=[...panel.querySelectorAll('button,input,select')];
        const before=controls.map(e=>e.disabled); controls.forEach(e=>e.disabled=true);
        let layer=null,fileTarget=null,ok=false;
        try {
            const directory=await directoryPromise;
            assert(valid() && selected===model && choice===frozenChoice, 'Model or cleaning selection changed.');
            await queue(()=>preview?.verify(scene));
            const dialog=await scene.events.invoke('show.exportPopup',format,[model.name],{directory});
            if(!dialog) {status('Export cancelled.');return;}
            ({fileTarget}=dialog);
            assert(valid() && selected===model && choice===frozenChoice, 'Model changed during export dialog.');
            await queue(()=>preview?.verify(scene));
            const {fileType,options}=exportChoices(format,dialog);
            const {layers}=makeExportLayers(model,frozenChoice.selection);layer=layers[0];
            const report=buildReport({modelName:model.name,filename:options.filename,format:fileType,density,
                config:frozenChoice.config,selection:frozenChoice.selection,total:model.instances.count,
                attributeStatus:data.attributeStatus,components,splatTransform:stDetails,sns:snsDetails});
            const stream=fileTarget?await fileTarget.handle.createWritable():undefined;
            ok=await scene.events.invoke('scene.write',fileType,options,stream,{splats:layers,throwOnError:true});
            if(ok!==true) {status('Native model export failed.');return;}
            // Successful model write and successful report are distinct outcomes.
            // Never issue provenance for a source that changed during the native write.
            try {
                assert(valid() && selected===model && choice===frozenChoice, 'Model/selection changed during native export.');
                await queue(()=>preview?.verify(scene));
            } catch(e) {status(`Model exported, but report withheld: ${showError(e)}`);return;}
            let reportResult;
            try { reportResult=await saveReport(report,dialog.directory??directory); }
            catch(e) {status(`Model exported; report failed: ${showError(e)}`);return;}
            status(`Cleaned model exported (${frozenChoice.selection.retainedCount.toLocaleString()} subset instances). Report: ${reportResult.filename} (${reportResult.delivery}).`);
        } catch(e) {status(ok===true ? `Model exported, but post-export operation failed: ${showError(e)}` : `Export failed: ${showError(e)}`);}
        finally {
            try {layer?.destroy();} catch(e) {failure=e;status(`Temporary export layer cleanup failed: ${showError(e)}`);}
            if(!ok) try {await fileTarget?.discard?.();}catch(_){}
            controls.forEach((e,i)=>e.disabled=before[i]);
            busy=false;activeExport=false;updateExportReadiness();
        }
    }
    function openPanel() {
        if(panel) {panel.hidden=false;panel.style.display='flex';windowControls?.restoreWindow();refreshModels();return;}
        panel=document.createElement('section'); panel.id='splat-cleaner-panel'; panel.className='blocks-shortcuts';
        panel.setAttribute('aria-label','Region-Aware Splat Cleaner');
        panel.style.cssText='position:fixed;z-index:1203;left:clamp(16px,4vw,72px);bottom:16px;width:min(430px,calc(100vw - 32px));height:min(600px,calc(100vh - 32px));min-width:min(340px,calc(100vw - 32px));min-height:min(320px,calc(100vh - 32px));max-width:calc(100vw - 32px);max-height:calc(100vh - 32px);resize:both;overflow:hidden;display:flex;flex-direction:column;box-sizing:border-box;padding:12px;background:#262b32;color:#f2f5f7;border:1px solid #7a838e;border-radius:9px;font:13px system-ui,sans-serif;box-shadow:0 8px 26px #0008';
        panel.innerHTML=panelHTML();
        uiHost.append(panel);
        windowControls=attachPluginWindow(panel,get('sc-window-body'),get('sc-minimize'));
        get('sc-models').onclick=()=>refreshModels();
        get('sc-model').onchange=()=>{
            if(busy || activeExport || preview) {refreshModels();status('Restore preview before changing models.');return;}
            const models=loadedSplats(scene), value=get('sc-model').value;
            selected=value===''?null:models[Number(value)]??null;clearCache();refreshModels();
        };
        get('sc-analyze').onclick=()=>track(doAnalyze());
        get('sc-sns-find').onclick=()=>track(doSnsSupport());
        get('sc-find-components').onclick=()=>track(doFindComponents());
        get('sc-st-find').onclick=()=>track(doSplatTransformFloaters().catch(e=>status(`SplatTransform unavailable: ${showError(e)}`)));
        get('sc-component-max').addEventListener('change',updateComponentSummary);
        for(const id of ['sc-sns-k','sc-sns-m'])get(id).addEventListener('change',invalidateSnsSettings);
        get('sc-opacity-encoding').addEventListener('change',()=>{
            // GPU Floaters depend on the source opacity interpretation;
            // CPU SNS does not. Never silently reuse a GPU result with another encoding.
            if(stMask || stDetails) {
                stMask=null;stDetails=null;
                get('sc-st-enabled').checked=false;get('sc-st-enabled').disabled=true;
                get('sc-st-status').textContent='Stale — opacity encoding changed. Click Analyze, then Analyze GPU Floaters.';
            }
            invalidateAppliedSelection('Opacity interpretation changed. Reanalyze before using opacity/GPU rules; SNS remains cached.');
        });
        const runApply=(reuseSelection=false)=>track((async()=>{
            if(busy)return;busy=true;
            try{await applyPreview(reuseSelection);}catch(e){
                choice=null;
                if (/device.{0,35}lost|GPUBuffer|DEVICE_HUNG|DEVICE_REMOVED|writeBuffer/i.test(showError(e))) {
                    gpuUnavailable=true;
                    if(preview?.uploadFailed) {
                        // CPU flags were reverted in setHidden(). Avoid a second GPU
                        // upload on a device that is already known to be unavailable.
                        try { if(lockedColor && originalColor) lockedColor.copy(originalColor); }
                        catch(ignored) { failure=ignored; }
                        try { isolation?.restore(); } catch(ignored) { failure=ignored; }
                        preview=null; isolation=null; originalColor=null;lockedColor=null;
                    }
                    restoreError='GPU flag upload failed; GPU contents cannot be verified without Editor reload.';
                    status(`GPU preview unavailable: ${showError(e)}. Reload the Editor before retrying.`);
                } else status(`Preview not applied: ${showError(e)}`);
            }
            finally{busy=false;refreshModels();updateExportReadiness();}
        })());
        get('sc-apply').onclick=()=>runApply(false);
        for (const id of ['sc-view','sc-isolate']) get(id).onchange=()=>{
            if(!data || !density)return;
            if(choice)runApply(true);
            else status('Select cleaning rules, then click Apply / Preview before switching views.');
        };
        const configIDs=new Set(['sc-density','sc-size-enabled','sc-size-p','sc-opacity-enabled','sc-opacity',
            'sc-sns-enabled',
            'sc-floater-enabled','sc-component-max','sc-component-select','sc-st-enabled']);
        panel.addEventListener('change',event=>{
            if(configIDs.has(event.target.id))
                invalidateAppliedSelection('Cleaning scope or rule changed.');
        });
        get('sc-restore').onclick=()=>track((async()=>{if(busy)return;busy=true;try{await restore();status('Original Gaussian flags and unrelated model visibility restored.');}catch(e){failure=e;status(showError(e));}finally{busy=false;refreshModels();}})());
        get('sc-roi-reset').onclick=()=>{if(!density || (busy && !selectionRestoring) || activeExport)return; for(const axis of AXES){roiRanges[axis]={...density.bounds[axis]};syncAxis(axis);}markRoiChanged();status('XYZ ROI reset to exact model bounds. Click Apply / Preview.');};
        get('sc-export').onclick=()=>track(doExport().catch(e=>status(`Export unavailable: ${showError(e)}`)));
        get('sc-hide').onclick=()=>{
            if(busy||activeExport){status('Finish the current operation first.');return;}
            track((async()=>{try{await restore();panel.hidden=true;panel.style.display='none';}catch(e){failure=e;status(showError(e));}})());
        };
        refreshModels();updateExportReadiness();
    }
    const added=scene.events.on('scene.elementAdded',()=>{if(panel && !busy)refreshModels();});
    const removed=scene.events.on('scene.elementRemoved',element=>{
        if(selected===element) {
            ++generation;selected=null;clearCache();
            if(preview?.splat===element) { // disposed resources must NOT be touched
                preview=null;
                try { if(lockedColor && originalColor) lockedColor.copy(originalColor); }
                catch(e) { failure=e; }
                lockedColor=null;originalColor=null;
                try{isolation?.restore();}catch(e){failure=e;}isolation=null;
            }
            status('Selected model removed; previous analysis invalidated. Refresh and select another model.');
        }
        if(panel && !busy)refreshModels();
    });
    return {
        async open() { assert(!stopped,'Plugin is deactivated.');openPanel(); },
        isRunning() {
            // Plugin Manager polls this synchronously. Never throw here: a
            // GPU failure must not trigger a cascade of status-query errors.
            return !!(busy||activeExport||tasks.size||preview||(panel&&!panel.hidden)); },
        async deactivate() {
            if(stopped) {if(failure||restoreError)throw new Error(showError(failure||restoreError));return;}
            stopped=true;++generation;
            try {
                const result=await Promise.allSettled([...tasks]);
                const bad=result.find(r=>r.status==='rejected');if(bad)throw bad.reason;
                await restore();
                if(failure||restoreError)throw new Error(showError(failure||restoreError));
            } catch(e) {failure=e;throw e;}
            finally {added.off();removed.off();windowControls?.dispose();windowControls=null;panel?.remove();panel=null;data=null;density=null;components=null;stMask=null;stDetails=null;snsMask=null;snsDetails=null;choice=null;}
        }
    };
}

// Source-level hooks for automated tests; not part of the Plugin Manager lifecycle contract.
export const __testing = {validatedSnsParameters,MAX_UNVALIDATED_GPU_FLOATERS,readModel,Preview,similarTransformScale,loadedSplats,modelAttached,makeExportLayers,exportChoices,isolationFor,display3,round3,reviseRoiInterval,panelHTML,axisMarkup,attachPluginWindow};
