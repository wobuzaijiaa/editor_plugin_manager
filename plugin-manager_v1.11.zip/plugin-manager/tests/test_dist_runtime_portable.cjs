'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {spawn}=require('node:child_process');
const http=require('node:http');
const root=path.resolve(__dirname,'../..');
const manager=path.join(root,'plugin-manager');

function freePort(){return new Promise((resolve,reject)=>{
    const s=http.createServer();s.once('error',reject);
    s.listen(0,'127.0.0.1',()=>{const n=s.address().port;s.close(()=>resolve(n));});
});}
async function eventually(url,child){
    for(let i=0;i<100;i++){
        if(child.exitCode!==null || child.signalCode!==null)throw Error(`backend exited ${child.exitCode}`);
        try{return await fetch(url);}catch{await new Promise(r=>setTimeout(r,30));}
    }
    throw Error('backend did not start');
}
test('C-P01: only backend files under dist/runtime work without source checkout',async t=>{
    const tmp=await fs.mkdtemp(path.join(os.tmpdir(),'spm-final-dist-'));
    t.after(()=>fs.rm(tmp,{recursive:true,force:true}));
    const dist=path.join(tmp,'supersplat','dist');const runtime=path.join(dist,'runtime');
    await fs.mkdir(path.join(dist,'plugins'),{recursive:true});
    await fs.mkdir(runtime);
    await fs.writeFile(path.join(dist,'plugins','manifest.json'),JSON.stringify({schema_version:1,plugins:[]}));
    await fs.writeFile(path.join(runtime,'package.json'),'\u007b"type":"module","private":true\u007d');
    for(const name of ['management-server.cjs','management-core.cjs','custom-editor.js','plugin-compat.cjs','typescript-loader.cjs']){
        await fs.copyFile(path.join(manager,name),path.join(runtime,name));
    }
    const port=await freePort();
    const args=[path.join(runtime,'management-server.cjs'),'--dist',dist,'--port',String(port),
        '--editor-origin','http://127.0.0.1:3013'];
    const child=spawn(process.execPath,args,{stdio:['ignore','pipe','pipe']});
    const stderr=[];child.stderr.on('data',c=>stderr.push(String(c)));
    t.after(async()=>{if(child.exitCode===null&&child.signalCode===null){child.kill();await new Promise(r=>child.once('exit',r));}});
    const url=`http://127.0.0.1:${port}`;
    assert.equal((await eventually(url+'/api/plugins/capabilities',child)).status,200,stderr.join(''));
    assert.equal((await fetch(url+'/index.html')).status,404);
    const cat=(await (await fetch(url+'/api/plugins',{headers:{Origin:'http://127.0.0.1:3013'}})).json());
    assert.equal(cat.plugins.length,0);
    assert.deepEqual(JSON.parse(await fs.readFile(path.join(dist,'plugins','manifest.json'),'utf8')),{schema_version:1,plugins:[]});
});
test('C-P02: deployment adds backend code only and root scripts use original environment',async()=>{
    const launch=await fs.readFile(path.join(root,'start_architecture_c.ps1'),'utf8');
    const deploy=await fs.readFile(path.join(root,'deploy_runtime.ps1'),'utf8');
    const maintenance=await fs.readFile(path.join(root,'maintain_editor.ps1'),'utf8');
    const bat=await fs.readFile(path.join(root,'maintain_editor.bat'),'utf8');
    const run=await fs.readFile(path.join(root,'run_supersplatEditor_p3013.bat'),'utf8');
    const stop=await fs.readFile(path.join(root,'stop_supersplatEditor_p3013.bat'),'utf8');
    assert.match(launch,/\$Root = Split-Path -Parent \$MyInvocation\.MyCommand\.Path/);
    assert.match(launch,/\$Dist = Join-Path \$Source 'dist'/);
    assert.match(launch,/\$Runtime = Join-Path \$Dist 'runtime'/);
    assert.match(launch,/\$ServePackageFile = Join-Path \$Source 'node_modules\\serve\\package.json'/);
    assert.match(launch,/\$LogRoot = Join-Path \$Root 'logs\\run_logs'/);
    assert.match(launch,/\('"' \+ \$ServeCli \+ '"'\),'dist','-C'/);
    assert.match(launch,/\$UpstreamPkg\.scripts\.serve -ceq 'serve dist -C'/);
    assert.doesNotMatch(launch,/dist.node_modules|Get-FileHash|& \$Npm/);
    assert.match(deploy,/\$Dest = Join-Path \$Dist 'runtime'/);
    assert.match(deploy,/\$BackendFiles = @\('management-server\.cjs'/);
    assert.match(deploy,/\$ServePkg = Join-Path \$Source 'node_modules\\serve\\package.json'/);
    assert.doesNotMatch(deploy,/& \$Npm|Copy-Item.*node_modules|Get-FileHash|runtime_templates/);
    assert.match(deploy,/Legacy\/unknown item under dist/);
    assert.match(deploy,/Unrecognized file under dist\/runtime/);
    assert.match(maintenance,/function AssertCleanNativeNamespaces/);
    assert.match(maintenance,/AssertCleanNativeNamespaces\s+RestorePluginStore/);
    assert.match(maintenance,/function RestoreRuntime/);
    assert.match(maintenance,/function RestoreFailedBuild/);
    assert.match(maintenance,/runtime_deploy/);
    assert.match(maintenance,/NOT_APPLICABLE_SAME_ORIGIN/);
    assert.doesNotMatch(bat,/"%ROOT%deploy_runtime\.ps1"/);
    assert.match(run, /%ROOT%start_architecture_c.ps1/);
    assert.match(stop, /%ROOT%start_architecture_c.ps1/);
    for(const f of ['start_architecture_c.ps1','run_supersplatEditor_p3013.bat','stop_supersplatEditor_p3013.bat']){
        assert.ok(await fs.stat(path.join(root,f)));
    }
});
test('C-P03: deployed runtime resolves TypeScript from supersplat/node_modules',async t=>{
    const tmp=await fs.mkdtemp(path.join(os.tmpdir(),'spm-final-env-'));
    t.after(()=>fs.rm(tmp,{recursive:true,force:true}));
    const source=path.join(tmp,'supersplat');
    const runtime=path.join(source,'dist','runtime');
    const modulePath=path.join(source,'node_modules','typescript');
    await fs.mkdir(runtime,{recursive:true});
    await fs.mkdir(modulePath,{recursive:true});
    await fs.writeFile(path.join(modulePath,'index.js'),'module.exports={createSourceFile(){return true}};\n');
    await fs.copyFile(path.join(manager,'typescript-loader.cjs'),path.join(runtime,'typescript-loader.cjs'));
    await fs.writeFile(path.join(runtime,'check.cjs'),`const assert=require('node:assert/strict');const l=require('./typescript-loader.cjs');assert.ok(l.typeScriptFrom(${JSON.stringify(source)}).createSourceFile);`);
    const c=spawn(process.execPath,[path.join(runtime,'check.cjs')],{stdio:['ignore','pipe','pipe']});
    const errs=[];c.stderr.on('data',b=>errs.push(String(b)));
    assert.equal(await new Promise((resolve,reject)=>{c.on('error',reject);c.on('exit',resolve);}),0,errs.join(''));
});
test('C-P04: startup scripts must remain outside dist and backend process is explicit',async()=>{
    const ps=await fs.readFile(path.join(root,'start_architecture_c.ps1'),'utf8');
    assert.match(ps,/\$BackendScript = Join-Path \$Runtime 'management-server\.cjs'/);
    assert.match(ps,/'--dist',\('"' \+ \$Dist \+ '"'\)/);
    assert.match(ps,/'--no-port-switching'/);
    assert.match(ps,/Get-OwnedProcess/);
    assert.match(ps,/Assert-ListenerOwned/);
    assert.match(ps,/\$StateFile = Join-Path \$LogRoot/);
});
