'use strict';
/** Architecture C: management-only local HTTP server, no Editor static delivery. */
const http=require('node:http');
const path=require('node:path');
const {createManagementRouter,json,verify}=require('./management-core.cjs');
async function createManagementServer({dist,port=3014,host='127.0.0.1',editorOrigin}={}) {
    verify(host==='127.0.0.1','Management backend must bind to 127.0.0.1 only');
    verify(Number.isInteger(port) && (port===0 || port>=1024) && port<=65535,'Invalid port');
    verify(typeof editorOrigin==='string' && editorOrigin.length>0,'--editor-origin required');
    const manager=await createManagementRouter({dist,allowedOrigins:[editorOrigin]});
    const server=http.createServer((req,res)=>{
        manager.handle(req,res).then(handled=>{
            if(!handled) json(res,404,{error:'Management API only'});
        }).catch(e=>{
            if(res.headersSent){res.destroy();return;}
            json(res,e.status||500,{error:e.status?e.message:`Plugin service error: ${e.message||e}`,
                ...(e.code === 'PLUGIN_REMOVE_RENAME_FAILED' ? {
                    code:e.code, filesystemCode:e.filesystemCode, attempts:e.attempts,
                    catalogChanged:false
                } : {})});
        });
    });
    return {server,root:manager.root,pluginRoot:manager.pluginRoot,host,port};
}
if (require.main===module) {
    const args=process.argv.slice(2);
    let dist=path.resolve(__dirname,'../supersplat/dist'),port=3014,editorOrigin=null;
    for(let i=0;i<args.length;i++) {
        if(args[i]==='--dist' && args[i+1]) dist=path.resolve(args[++i]);
        else if(args[i]==='--port' && args[i+1]) port=Number(args[++i]);
        else if(args[i]==='--editor-origin' && args[i+1]) editorOrigin=args[++i];
        else {process.stderr.write('Usage: node plugin-manager/management-server.cjs --dist <supersplat/dist> --port 3014 --editor-origin http://127.0.0.1:3013\n');process.exit(2);}
    }
    createManagementServer({dist,port,editorOrigin}).then(({server,root})=>server.listen(port,'127.0.0.1',()=>
        process.stdout.write(`SuperSplat management backend: http://127.0.0.1:${port}/api/plugins/capabilities (dist: ${root})\n`)))
        .catch(e=>{process.stderr.write(`Management backend startup failed: ${e.message||e}\n`);process.exitCode=1;});
}
module.exports={createManagementServer};
