const test=require('node:test');
const assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {resolve}=require('node:path');
const promise=import(pathToFileURL(resolve(__dirname,'..','auto-voxel.mjs')).href);
function fixture(n=1200,s=0.03, factor=1) {
    const c={x:new Float32Array(n),y:new Float32Array(n),z:new Float32Array(n),
        scale_0:new Float32Array(n),scale_1:new Float32Array(n),scale_2:new Float32Array(n)};
    for(let i=0;i<n;i++){
        c.x[i]=factor*((i%100)/10);c.y[i]=factor*((Math.floor(i/100)%12)/10);
        c.z[i]=factor*(i%7)/100;
        c.scale_0[i]=Math.log(s*factor*0.1);c.scale_1[i]=Math.log(s*factor);c.scale_2[i]=Math.log(s*factor*4);
    }
    return c;
}
test('AUTO-01 automatic sizing is positive, finite and uses upstream opacity defaults',async()=>{
    const {autoVoxelResolution}=await promise;
    const result=autoVoxelResolution(fixture());
    assert(result.voxelResolution>0 && Number.isFinite(result.voxelResolution));
    assert.equal(result.opacityCutoff,0.1);assert.equal(result.minContribution,1/255);
    assert(result.estimatedGridCells<=result.maxEstimatedGridCells);
});
test('AUTO-02 uniform model scaling produces proportional world-space voxel resolution',async()=>{
    const {autoVoxelResolution}=await promise;
    const a=autoVoxelResolution(fixture(1000,0.02,1));
    const b=autoVoxelResolution(fixture(1000,0.02,7));
    assert(Math.abs(a.voxelResolution*7-b.voxelResolution)/b.voxelResolution<1e-5);
});
test('AUTO-03 extreme logarithmic scales and malformed arrays fail closed',async()=>{
    const {autoVoxelResolution}=await promise;
    const c=fixture();c.scale_1[0]=NaN;
    assert.throws(()=>autoVoxelResolution(c),/Invalid Gaussian log-scale/);
    assert.throws(()=>autoVoxelResolution({x:new Float32Array(1)}),/Incomplete instance-aligned/);
});
test('AUTO-04 large scenes meet the specified grid budget',async()=>{
    const {autoVoxelResolution}=await promise;
    const c=fixture(50_000,0.0001);
    for(let i=0;i<c.x.length;i++){c.x[i]=i%1000;c.y[i]=Math.floor(i/1000);c.z[i]=i%100;}
    const result=autoVoxelResolution(c,{maxCells:100000});
    assert(result.estimatedGridCells<=100000);
});
test('AUTO-05 coincident centers still use Gaussian extent for sizing',async()=>{
    const {autoVoxelResolution}=await promise;
    const c=fixture(20);c.x.fill(1);c.y.fill(2);c.z.fill(3);
    const result=autoVoxelResolution(c);
    assert(result.voxelResolution>0 && Number.isFinite(result.voxelResolution));
});
test('AUTO-06 camera/editor axis translation does not change automatic voxel width',async()=>{
    const {autoVoxelResolution}=await promise;
    const c=fixture(),a=autoVoxelResolution(c);
    c.x=c.x.map(x=>x+50);c.y=c.y.map(y=>y-14);
    const b=autoVoxelResolution(c);
    assert(Math.abs(a.voxelResolution-b.voxelResolution)/a.voxelResolution<1e-4);
});
