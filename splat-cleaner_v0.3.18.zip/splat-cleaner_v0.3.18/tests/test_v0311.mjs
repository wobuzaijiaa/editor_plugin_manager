import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import {__testing} from '../index.js';
import {analyzeDensity,analyzeComponents,computeSelection} from '../core.mjs';
import {analyzeSnsBidirectionalSupport,gaussianMetric,readSnsGeometry} from '../sns-support.mjs';
import {autoVoxelResolution} from '../auto-voxel.mjs';
import {checkFloaterCapacity} from '../vendor/splat-transform-filter.mjs';
const read = name=>readFileSync(new URL('../'+name,import.meta.url),'utf8');
const pts = p=>Object.fromEntries(['x','y','z'].map((a,i)=>[a,Float64Array.from(p,v=>v[i])]));
const I=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const bigLimits={maxBufferSize:2**31,maxStorageBufferBindingSize:2**31};
const limits128={maxBufferSize:2**30,maxStorageBufferBindingSize:2**27};

test('CAP-01 UI range and defaults; existing single SNS and Apply controls',()=>{
    const html=read('index.js');
    assert.match(html,/id="sc-sns-k" type="number" min="1" max="10" step="0.5" value="3"/);
    assert.match(html,/id="sc-sns-m" type="number" min="1" max="50" step="1" value="1"/);
    assert.match(html,/id="sc-component-max" type="number" min="1" max="1000000" step="10" value="500"/);
    for(const id of ['sc-apply','sc-sns-find'])assert.equal(html.match(new RegExp(`id="${id}"`,'g')).length,1);
    assert.deepEqual(__testing.validatedSnsParameters('10','50'),{k:10,m:50});
    for(const [k,m] of [[10.5,1],[3,51],[3,1.5],[9.7,1]])assert.throws(()=>__testing.validatedSnsParameters(k,m));
    assert.equal(__testing.MAX_UNVALIDATED_GPU_FLOATERS,undefined);
});
test('CAP-02 actual SNS search supports m=50 and k=10, counts do not overflow',async()=>{
    const n=51, k=10,c=pts(Array.from({length:n},(_,i)=>[i/10,0,0]));
    const g=gaussianMetric([1,0,0,0],[0,0,0],I,k);
    const geometry={k,inverse:new Float32Array(n*9),radii:new Float64Array(n).fill(g.radius),valid:new Uint8Array(n).fill(1),locked:new Uint8Array(n)};
    for(let i=0;i<n;i++)geometry.inverse.set(g.inverse,9*i);
    const r=await analyzeSnsBidirectionalSupport(c,geometry,{k,minSupport:50});
    assert.equal(r.candidateCount,0);assert.equal(r.supportedCount,n);assert.ok(r.supportCount.every(v=>v===50));
    assert.equal(r.outgoingCellBudget,16384);assert.equal(r.outgoingComparisonBudget,100000);
    assert.equal(r.reverseNodeBudget,16384);assert.equal(r.reverseComparisonBudget,100000);
    await assert.rejects(analyzeSnsBidirectionalSupport(c,geometry,{k,minSupport:51}),/1–50/);
    await assert.rejects(readSnsGeometry(null,null,{k:10.5}),/1–10/);
});
test('CAP-03 expanded default density and component resolution remain valid and configurable',async()=>{
    const c=pts(Array.from({length:1000},(_,i)=>[i%10,Math.floor(i/10)%10,Math.floor(i/100)]));
    const d=await analyzeDensity(c);assert.equal(d.resolution,128);assert.equal(d.classCounts.reduce((a,b)=>a+b,0),1000);
    const old=await analyzeDensity(c,{resolution:64});assert.equal(old.resolution,64);
    // Effective divisions depend on N; dense enough input to distinguish 48 vs 96.
    const n=270000,large={x:new Float64Array(n),y:new Float64Array(n),z:new Float64Array(n)};
    for(let i=0;i<n;i++){large.x[i]=i%100;large.y[i]=Math.floor(i/100)%100;large.z[i]=Math.floor(i/10000);}
    const comp=await analyzeComponents(large);assert.ok(comp.resolutionDivisions>48&&comp.resolutionDivisions<=96);assert.equal(comp.sizes.reduce((a,b)=>a+b,0),n);
    assert.ok(comp.occupiedCells<=500000);
});
test('CAP-04 1M component threshold is accepted by computeSelection and tint eligibility',()=>{
    const c=pts([[0,0,0],[1,0,0],[2,0,0]]),d={classes:new Uint8Array(3)},component={labels:Uint32Array.of(0,0,1),sizes:Uint32Array.of(2,1),largestId:0};
    const config={roi:{x:{min:0,max:2},y:{min:0,max:0},z:{min:0,max:0}},density:'all',floaterEnabled:true,maxComponentGaussians:1_000_000};
    const s=computeSelection(c,d,config,{components:component});assert.deepEqual([...s.candidates],[0,0,1]);
    assert.throws(()=>computeSelection(c,d,{...config,maxComponentGaussians:1_000_001},{components:component}),/1000000/);
    assert.equal(__testing.methodTintEligible('floaters',{data:{centers:c},density:d,components:component,componentMax:1_000_000}),true);
});
test('CAP-05 restored voxel policy budgets and explicit expanded overrides',()=>{
    const n=1000,c={x:new Float32Array(n),y:new Float32Array(n),z:new Float32Array(n),scale_0:new Float32Array(n).fill(-9),scale_1:new Float32Array(n).fill(-9),scale_2:new Float32Array(n).fill(-9)};
    for(let i=0;i<n;i++){c.x[i]=i%10;c.y[i]=Math.floor(i/10)%10;c.z[i]=Math.floor(i/100);}
    const a=autoVoxelResolution(c);assert.equal(a.maxEstimatedGridCells,2_000_000);assert.equal(a.initialMaxAxisCells,256);assert.equal(a.scaleSampleLimit,8192);assert.ok(a.estimatedGridCells<=2_000_000);
    const b=autoVoxelResolution(c,{maxCells:4_000_000,maxAxisCells:512,sampleSize:16384});assert.ok(b.estimatedGridCells<=4_000_000);assert.ok(b.voxelResolution<=a.voxelResolution);
    assert.equal(a.opacityCutoff,.1);assert.equal(a.minContribution,1/255);
});
// Actual shipped adapter preflight, with no giant arrays or physical GPU allocations.
test('CAP-06 adapter checks smaller of buffer and binding limits, exact boundary and hardware-derived capacity',async()=>{
    const old=Object.getOwnPropertyDescriptor(globalThis,'navigator');
    let limits=limits128,available=true;
    Object.defineProperty(globalThis,'navigator',{configurable:true,value:{gpu:{async requestAdapter(options){assert.equal(options.powerPreference,'high-performance');return available?{limits}:null;}}}});
    try{
        const r=await checkFloaterCapacity(2_097_152);assert.equal(r.requiredBytes,134217728);assert.equal(r.maxInstances,2_097_152);
        await assert.rejects(checkFloaterCapacity(2_097_153),/adapter capacity/);
        limits={maxBufferSize:2**27,maxStorageBufferBindingSize:2**31};await assert.rejects(checkFloaterCapacity(2_097_153),/adapter capacity/);
        limits=bigLimits;assert.equal((await checkFloaterCapacity(20_000_000)).requiredBytes,1_280_000_000);
        assert.equal((await checkFloaterCapacity(20_000_001)).maxInstances,33_554_432);
        await assert.rejects(checkFloaterCapacity(33_554_433),/adapter capacity/);
        await assert.rejects(checkFloaterCapacity(0x100000000),/uint32/);
        limits={};await assert.rejects(checkFloaterCapacity(1),/storage limits unavailable/);
        available=false;await assert.rejects(checkFloaterCapacity(1),/adapter unavailable/);
    }finally{if(old)Object.defineProperty(globalThis,'navigator',old);else delete globalThis.navigator;}
});
// Execute the literal generated bridge entry against mocked upstream APIs. The
// real GPU setup path uses createDevice before GpuVoxelization allocates.
function mockEntry(deviceLimits,{webgpu=true,loseDevice=false,fail=false}={}) {
    const source=read('vendor/splat-transform-filter.mjs');
    const entry=source.slice(source.indexOf('WorkerQueue.maxWorkers = 0;',source.lastIndexOf('/** Release-time entry.')),source.indexOf('\nfunction createRequire()',source.lastIndexOf('/** Release-time entry.')));
    const stats={destroyed:0,uploads:0};
    let lossListener;
    const runtime=runInNewContext(entry+'\n;({filterFloatersWithIds,checkFloaterCapacity})',{
        WorkerQueue:{},DataTable:class{},Column:class{},document:{createElement:()=>({})},DEVICETYPE_WEBGPU:'webgpu',
        createGraphicsDevice:async()=>({isWebGPU:webgpu,wgpu:{limits:deviceLimits},on(name,fn){assert.equal(name,'devicelost');lossListener=fn;},off(name,fn){assert.equal(name,'devicelost');if(lossListener)assert.equal(fn,lossListener);lossListener=null;},destroy(){stats.destroyed++;}}),
        processDataTable:async(_t,_f,{createDevice})=>{await createDevice();stats.uploads++;if(loseDevice)lossListener();if(fail)throw new Error('mock readback interrupted');return {getColumnByName:()=>({data:Uint32Array.of(0)})};}
    });
    return {runtime,stats};
}
test('CAP-07 actual-device capacity failure prevents upstream allocation and destroys owned device',async()=>{
    const {runtime,stats}=mockEntry(limits128);
    await assert.rejects(runtime.filterFloatersWithIds({x:{length:2_097_153}},{}),/device capacity/);
    assert.deepEqual(stats,{uploads:0,destroyed:1});
});
test('CAP-08 actual-device valid capacity allows upload; WebGL fallback fails closed',async()=>{
    const good=mockEntry(bigLimits);const result=await good.runtime.filterFloatersWithIds({x:{length:22_000_000}},{});
    assert.deepEqual([...result],[0]);assert.deepEqual(good.stats,{uploads:1,destroyed:1});
    const fallback=mockEntry(bigLimits,{webgpu:false});await assert.rejects(fallback.runtime.filterFloatersWithIds({x:{length:1}},{}),/WebGPU graphics device/);assert.deepEqual(fallback.stats,{uploads:0,destroyed:1});
});
test('CAP-09 controller preflights before columns and preserves report provenance',()=>{
    const src=read('index.js'),fn=src.slice(src.indexOf('async function doSplatTransformFloaters()'),src.indexOf('async function doExport()'));
    assert.ok(fn.indexOf('bridge.checkFloaterCapacity(instances.count)')<fn.indexOf('await readFloaterColumns('));
    assert.match(fn,/adapter_capacity:capacity/);assert.match(src,/outgoing_search_limits:/);
});

test('CAP-10 11M input permitted by 1 GiB binding, rejected by 512 MiB binding',async()=>{
    const old=Object.getOwnPropertyDescriptor(globalThis,'navigator');
    let limits={maxBufferSize:2**30,maxStorageBufferBindingSize:2**30};
    Object.defineProperty(globalThis,'navigator',{configurable:true,value:{gpu:{async requestAdapter(){return {limits};}}}});
    try {const r=await checkFloaterCapacity(11_000_000);assert.equal(r.requiredBytes,704_000_000);assert.equal(r.maxInstances,16_777_216);
        limits={maxBufferSize:2**30,maxStorageBufferBindingSize:2**29};await assert.rejects(checkFloaterCapacity(11_000_000),/adapter capacity/);
    }finally{if(old)Object.defineProperty(globalThis,'navigator',old);else delete globalThis.navigator;}
});
test('CAP-11 observed device loss rejects even a nominal upstream success; owned device cleaned up',async()=>{
    const {runtime,stats}=mockEntry(bigLimits,{loseDevice:true});
    await assert.rejects(runtime.filterFloatersWithIds({x:{length:11_000_000}},{}),/GPU device lost/);
    assert.deepEqual(stats,{uploads:1,destroyed:1});
});
test('CAP-12 observed device loss labels a generic upstream error and does not retry',async()=>{
    const {runtime,stats}=mockEntry(bigLimits,{loseDevice:true,fail:true});
    await assert.rejects(runtime.filterFloatersWithIds({x:{length:11_000_000}},{}),/GPU device lost.*mock readback interrupted/);
    assert.deepEqual(stats,{uploads:1,destroyed:1});
});
test('CAP-13 no fixed model-size guard; fresh run invalidates choice; loss gates later GPU work',()=>{
    const src=read('index.js'),fn=src.slice(src.indexOf('async function doSplatTransformFloaters()'),src.indexOf('async function doExport()'));
    assert.doesNotMatch(src,/MAX_UNVALIDATED_GPU_FLOATERS/);
    assert.ok(fn.indexOf('++selectionRevision;methodRefreshPending=false;choice=null;')<fn.indexOf('await restore('));
    assert.match(fn,/console.info\(.*adapterCapacity:capacity/);
    assert.match(fn,/gpuUnavailable=true/);assert.match(src,/get\('sc-st-find'\)\.disabled=busy \|\| !selected \|\| gpuUnavailable/);
    assert.equal((fn.match(/await runSplatTransformFloaters\(/g)||[]).length,1);
});
