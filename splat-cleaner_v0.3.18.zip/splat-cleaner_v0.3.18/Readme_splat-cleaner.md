# SuperSplat Editor — Region-Aware Splat Cleaner

An independently managed plugin for [PlayCanvas SuperSplat Editor](https://github.com/playcanvas/supersplat), providing **3D Gaussian Splatting (3DGS) cleanup through complementary detection methods, spatial selection, reversible visual inspection and selective export**.

**Version:** v0.3.18  
**Plugin Manager:** v1.11  
**Editor references:** SuperSplat **v3.7.0**, **v3.8.0** and **v3.8.1**  (reviewed versions, not guaranteed compatibility across releases). 
**GPU runtime:** SplatTransform v3.11.2 / PlayCanvas v2.24.1

The plugin can be installed and updated through Plugin Manager without modifying upstream SuperSplat TypeScript or rebuilding the Editor.

## Motivation

3DGS reconstructions may contain isolated Gaussians, floating artifacts, oversized splats and unwanted geometry. Manually identifying and removing these artifacts can be time-consuming, particularly in large scenes.

Region-Aware Splat Cleaner combines complementary cleaning methods with spatial selection and visual inspection, allowing users to evaluate proposed changes before exporting a cleaned model.

The objective is to assist interactive cleaning rather than automatically determine rendering quality.

## Features

- **Scale-Normalized Spacing (SNS):** Identifies unsupported Gaussians using bidirectional, covariance-normalized neighboring-center support. Hybrid CPU/GPU processing accelerates outgoing analysis and reverse coverage.
- **GPU Floaters:** Independent SplatTransform voxel-contribution filtering for detecting floating artifacts.
- **Additional cleaning rules:** Size, Opacity and detached-component detection.
- **Region-aware selection:** XYZ bounds and density classes restrict candidate removal without limiting SNS neighborhood analysis.
- **Combined cleaning:** Five independently enabled rules combined using logical OR, with overlapping candidates counted once.
- **Independent analysis caches:** Reuse compatible detector results without unnecessary recomputation.
- **Automatic method refresh:** Update candidate selection when cleaning methods are enabled or disabled after the initial Apply / Preview.
- **Visual inspection:** Compare Original, Candidates and Cleaned views.
- **Method Tint:** Highlight one enabled cleaning method at a time in Original or Candidates view, with configurable color and opacity.
- **Selective export:** Export retained Gaussians as PLY, compressed PLY, SPLAT, SOG or SPZ, accompanied by a JSON cleaning report.

Preview operations are reversible and do not permanently delete source Gaussians or modify their appearance attributes.

## Scale-Normalized Spacing (SNS)

Overlapping Gaussians are a natural characteristic of 3DGS. SNS uses their learned spatial scales and orientations to identify Gaussians with insufficient local geometric support.

The analysis consists of two stages:

1. **Outgoing support:** Determine whether a Gaussian's covariance-defined neighborhood contains other Gaussian centers.
2. **Reverse support:** Determine whether initially unsupported Gaussians are covered by other Gaussians' neighborhoods.

Support in either direction contributes to the distinct-neighbor count.

| Parameter | Default | Range |
|---|---:|---|
| Extent k | 3 | 1–10, step 0.5 |
| Minimum neighbors m | 1 | Integer 1–50 |

Increasing k generally makes SNS less aggressive; increasing m requires stronger neighborhood support. These relationships assume complete searches.

SNS automatically manages GPU acceleration, CPU verification and fallback. Invalid or unresolved search results are conservatively retained.

SNS detects insufficient geometric support, not excessive overlap or rendered redundancy.

## Workflow

1. **Select and Analyze** — Load a model and click Analyze to establish geometry and density information.
2. **Detect candidates** — Run Analyze SNS, Analyze GPU Floaters or Find Components as required.
3. **Configure selection** — Enable the desired cleaning rules, adjust thresholds and optionally restrict XYZ or density scope.
4. **Apply / Preview** — Establish the cleaning selection and compare Original, Candidates and Cleaned views.
5. **Inspect** — Optionally use Method Tint to examine candidates from individual methods.
6. **Restore or Export** — Restore the temporary preview or export the retained Gaussians as a new model.

After the initial Apply / Preview, method-checkbox changes automatically refresh the selection using valid cached analysis results.

Changes to analysis parameters, XYZ bounds, density scope or selection thresholds require manual Apply / Preview. Compatible general Analyze operations preserve independent detector caches.

## Installation

Install through **SuperSplat Plugin Manager v1.11**:

1. Extract the complete plugin release, including `vendor/splat-transform-filter.mjs`.
2. Open **Plugins → Manage Plugins → Install Plugin** and select the extracted plugin folder.
3. Activate the plugin, optionally enable Startup, and save the configuration.
4. Open **Region-Aware Splat Cleaner** from the Plugins menu.

For updates:

Deactivate → Remove → Install → Activate

The bundled SplatTransform runtime is maintained independently, the official latest version.

No npm build is required when installing a complete plugin release.

## Limitations

- **Single-model processing:** Analysis operates on one selected model at a time.
- **Detection uncertainty:** Unsupported Gaussians are candidates, not confirmed artifacts. Legitimate sparse geometry may be selected, while clustered or mutually supported artifacts may remain.
- **GPU resources:** GPU Floater capacity is determined by WebGPU adapter and device-storage limits rather than a fixed instance-count ceiling. Passing capacity checks does not guarantee successful execution.
- **Memory usage:** Large models require substantial CPU/GPU memory for analysis, spatial indexing and preview.
- **Analysis validity:** External geometry or native-flag changes may require clearing cached results and reanalyzing the model.
- **Preview ownership:** Restore Cleaner preview before editing the model or activating another visibility-filtering plugin.
- **Compatibility:** The plugin uses selected internal SuperSplat interfaces. Other Editor versions require compatibility verification.

If GPU device loss or uncertain preview restoration occurs, reload the Editor before continuing.

**Visual inspection remains necessary before exporting cleaned models.**

## Validation Status

v0.3.18 has passed 191 automated plugin tests. Successful bidirectional SNS processing has also been reported on a model containing approximately 10.44 million Gaussians.

Optional CPU-reference and historical compatibility audits are available for investigating SNS classification differences.

GPU acceleration remains experimental. Successful processing does not establish universal device stability or visual-quality preservation.

## Documentation

- **SNS User Guide** — Settings, workflow, inspection and troubleshooting.
- **SNS Technical Reference** — Geometric rationale, mathematical definition, bidirectional support and detection limitations.
- **Source Architecture and Implementation Reference** — Module responsibilities, dataflow, analysis contracts, visualization and export.
- **Maintenance Guide** — Compatibility, testing, packaging and recovery.
- **Changelog and Test Report** — Release-specific changes, regression tests and performance measurements.
- **SplatTransform Filter Bridge Builder v1.0.2** — Independent vendor-runtime generation and maintenance.